import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import AnimatedCard from "@/components/AnimatedCard";
import { ArrowRight, Brain, Globe, Smartphone, BarChart3, ShoppingCart, Database } from "lucide-react";

const projects = [
  {
    title: "AI-Powered Credit Scoring Platform",
    desc: "Built a machine learning system for a financial services company that analyzes applicant data to predict creditworthiness with 94% accuracy, reducing default rates by 35%.",
    tech: ["Python", "TensorFlow", "React", "PostgreSQL"],
    impact: "35% reduction in loan defaults",
    icon: Brain,
    category: "AI / Machine Learning",
  },
  {
    title: "Multi-Vendor E-Commerce Marketplace",
    desc: "Developed a full-featured e-commerce platform supporting 200+ vendors, real-time inventory management, and integrated payment processing across multiple African markets.",
    tech: ["Next.js", "Node.js", "Stripe", "MongoDB"],
    impact: "10,000+ daily transactions",
    icon: ShoppingCart,
    category: "Web Platform",
  },
  {
    title: "Field Operations Mobile App",
    desc: "Created a cross-platform mobile application for an agricultural company to manage field operations, track crop health, and coordinate logistics in real-time.",
    tech: ["React Native", "Firebase", "Maps API", "Node.js"],
    impact: "40% improvement in field efficiency",
    icon: Smartphone,
    category: "Mobile Application",
  },
  {
    title: "Business Intelligence Dashboard",
    desc: "Designed and built a real-time analytics dashboard aggregating data from 15+ sources, providing executives with actionable insights and automated reporting.",
    tech: ["React", "D3.js", "Python", "AWS"],
    impact: "60% faster decision-making",
    icon: BarChart3,
    category: "Data Analytics",
  },
  {
    title: "Healthcare Management System",
    desc: "Built a comprehensive patient management and telemedicine platform for a healthcare network, enabling remote consultations and digital health records across 12 clinics.",
    tech: ["React", "Node.js", "PostgreSQL", "WebRTC"],
    impact: "12 clinics digitized",
    icon: Globe,
    category: "Enterprise Software",
  },
  {
    title: "Supply Chain Automation Platform",
    desc: "Developed an end-to-end supply chain management system with AI-driven demand forecasting, automated procurement, and real-time logistics tracking.",
    tech: ["Python", "React", "TensorFlow", "Docker"],
    impact: "25% cost reduction in logistics",
    icon: Database,
    category: "AI / Automation",
  },
];

const Projects = () => (
  <div className="min-h-screen pt-24">
    <section className="py-24 dot-pattern">
      <div className="container">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl">
          <span className="inline-block text-xs font-medium tracking-widest uppercase gradient-text mb-4">Portfolio</span>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.1]">
            Our <span className="gradient-text">Work</span> Speaks for Itself
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-2xl">
            Explore our portfolio of intelligent software solutions that have transformed businesses across Africa and beyond.
          </p>
        </motion.div>
      </div>
    </section>

    <section className="py-24 bg-surface">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project, i) => (
            <AnimatedCard key={i} delay={i * 0.08} gradient className="flex flex-col">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center flex-shrink-0">
                  <project.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <span className="text-xs font-medium text-primary uppercase tracking-wider">{project.category}</span>
              </div>
              <h3 className="text-lg font-bold mb-2">{project.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">{project.desc}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {project.tech.map((t, j) => (
                  <span key={j} className="text-xs rounded-full border border-border bg-surface px-2.5 py-1 text-muted-foreground">{t}</span>
                ))}
              </div>
              <div className="pt-4 border-t border-border">
                <span className="text-sm font-semibold gradient-text">{project.impact}</span>
              </div>
            </AnimatedCard>
          ))}
        </div>
      </div>
    </section>

    <section className="py-24">
      <div className="container text-center max-w-2xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="text-3xl font-bold">Have a Project in <span className="gradient-text">Mind</span>?</h2>
          <p className="mt-4 text-muted-foreground mb-8">Let's bring your vision to life with our expertise in software and AI.</p>
          <Button variant="gradient" size="lg" asChild>
            <a 
              href="mailto:mugwadiinnocent@gmail.com?subject=New%20Project%20Inquiry" 
              className="inline-flex items-center"
            >
              Start a Project <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  </div>
);

export default Projects;
