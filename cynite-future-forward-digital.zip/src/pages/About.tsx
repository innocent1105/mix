import { motion } from "framer-motion";
import SectionHeading from "@/components/SectionHeading";
import AnimatedCard from "@/components/AnimatedCard";
import { Target, Eye, Lightbulb, Layers, Code, Brain, Cloud, Database, Smartphone, Globe } from "lucide-react";

const techStack = [
  { icon: Code, label: "React / Next.js" },
  { icon: Brain, label: "TensorFlow / PyTorch" },
  { icon: Cloud, label: "AWS / Azure" },
  { icon: Database, label: "PostgreSQL / MongoDB" },
  { icon: Smartphone, label: "React Native / Flutter" },
  { icon: Globe, label: "Node.js / Python" },
];

const About = () => (
  <div className="min-h-screen pt-24">
    {/* Hero */}
    <section className="py-24 dot-pattern">
      <div className="container">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="max-w-3xl">
          <span className="inline-block text-xs font-medium tracking-widest uppercase gradient-text mb-4">About Us</span>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.1]">
            Pioneering Technology <span className="gradient-text">in Africa</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed max-w-2xl">
            Founded in Lusaka, Zambia, CYNITE Technologies is on a mission to bridge the technology gap in Africa by building world-class software and AI solutions.
          </p>
        </motion.div>
      </div>
    </section>

    {/* Mission & Vision */}
    <section className="py-24 bg-surface">
      <div className="container grid grid-cols-1 md:grid-cols-2 gap-8">
        <AnimatedCard gradient className="flex flex-col">
          <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center mb-4">
            <Target className="h-5 w-5 text-primary-foreground" />
          </div>
          <h3 className="text-xl font-bold mb-3">Our Mission</h3>
          <p className="text-muted-foreground leading-relaxed">
            To empower businesses across Africa and globally with intelligent, scalable technology solutions that drive growth, efficiency, and innovation. We believe every business deserves access to world-class software.
          </p>
        </AnimatedCard>

        <AnimatedCard delay={0.1} gradient className="flex flex-col">
          <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center mb-4">
            <Eye className="h-5 w-5 text-primary-foreground" />
          </div>
          <h3 className="text-xl font-bold mb-3">Our Vision</h3>
          <p className="text-muted-foreground leading-relaxed">
            To become Africa's leading technology partner, recognized globally for delivering innovative AI and software solutions that transform industries and create lasting impact.
          </p>
        </AnimatedCard>
      </div>
    </section>

    {/* Approach */}
    <section className="py-24">
      <div className="container">
        <SectionHeading label="How We Work" title="Our Approach" description="We combine deep technical expertise with a client-first methodology to deliver exceptional results." />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: Lightbulb, title: "Discovery & Strategy", desc: "We start by understanding your business, challenges, and goals to design the right solution architecture." },
            { icon: Code, title: "Agile Development", desc: "Iterative development with regular check-ins ensures transparency and rapid delivery of high-quality software." },
            { icon: Layers, title: "Scale & Support", desc: "We build for scale from day one, with ongoing support and optimization to ensure long-term success." },
          ].map((item, i) => (
            <AnimatedCard key={i} delay={i * 0.1}>
              <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center mb-4">
                <item.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="font-semibold mb-2">{item.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
            </AnimatedCard>
          ))}
        </div>
      </div>
    </section>

    {/* Founder */}
    <section className="py-24 bg-surface">
      <div className="container max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center">
          <span className="inline-block text-xs font-medium tracking-widest uppercase gradient-text mb-4">Our Story</span>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-6">Founded with Purpose</h2>
          <p className="text-muted-foreground leading-relaxed">
            CYNITE Technologies was born from a simple belief: Africa deserves technology solutions that match global standards. Starting from Lusaka, Zambia, we've grown into a team of passionate engineers, designers, and AI specialists committed to building software that makes a real difference. Every project we take on is driven by the desire to solve complex problems with elegant, intelligent solutions.
          </p>
        </motion.div>
      </div>
    </section>

    {/* Tech Stack */}
    <section className="py-24">
      <div className="container">
        <SectionHeading label="Our Stack" title="Technology We Use" description="We leverage the best modern tools and frameworks to build robust, scalable solutions." />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 max-w-4xl mx-auto">
          {techStack.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="flex flex-col items-center gap-2 p-5 rounded-lg bg-card border border-border soft-shadow hover:border-primary/30 transition-colors"
            >
              <t.icon className="h-7 w-7 text-primary" />
              <span className="text-xs text-muted-foreground text-center font-medium">{t.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default About;
