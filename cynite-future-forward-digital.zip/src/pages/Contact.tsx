import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import AnimatedCard from "@/components/AnimatedCard";
import { Mail, MapPin, Phone, Send } from "lucide-react";
import { toast } from "sonner";

const Contact = () => {
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("Message sent! We'll get back to you within 24 hours.");
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  return (
    <div className="min-h-screen pt-24">
      <section className="py-24 dot-pattern">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl">
            <span className="inline-block text-xs font-medium tracking-widest uppercase gradient-text mb-4">Contact</span>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.1]">
              Let's Build Something <span className="gradient-text">Great</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl">
              Ready to start your next project? Get in touch and let's discuss how we can help transform your business.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-24 bg-surface">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div className="space-y-6">
              <AnimatedCard className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center flex-shrink-0">
                  <Mail className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Email</h3>
                  <p className="text-sm text-muted-foreground">hello@cynite.tech</p>
                </div>
              </AnimatedCard>

              <AnimatedCard delay={0.1} className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center flex-shrink-0">
                  <Phone className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Phone</h3>
                  <p className="text-sm text-muted-foreground">+260 960 883 940</p>
                </div>
              </AnimatedCard>

              <AnimatedCard delay={0.2} className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Location</h3>
                  <p className="text-sm text-muted-foreground">Lusaka, Zambia</p>
                </div>
              </AnimatedCard>
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-2"
            >
              <form onSubmit={handleSubmit} className="rounded-lg border border-border bg-card p-6 md:p-8 space-y-6 soft-shadow">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" placeholder="Your name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="your@email.com" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company">Company</Label>
                  <Input id="company" placeholder="Your company" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input id="subject" placeholder="Project inquiry" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">Message</Label>
                  <Textarea id="message" placeholder="Tell us about your project..." rows={5} required className="resize-none" />
                </div>
                <Button variant="gradient" size="lg" type="submit" disabled={loading} className="w-full sm:w-auto">
                  {loading ? "Sending..." : "Send Message"} <Send className="ml-2 h-4 w-4" />
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="border-t border-border">
        <div className="h-[400px] bg-surface flex items-center justify-center">
          <iframe
            title="CYNITE Technologies Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d246004.45498197!2d28.19963269259064!3d-15.41690895278509!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1940f336b25b3c5d%3A0xa57d263e0bfb4c34!2sLusaka%2C%20Zambia!5e0!3m2!1sen!2s!4v1700000000000!5m2!1sen!2s"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>
    </div>
  );
};

export default Contact;
