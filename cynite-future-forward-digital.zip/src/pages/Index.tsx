import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import SectionHeading from "@/components/SectionHeading";
import AnimatedCard from "@/components/AnimatedCard";
import { Brain, Cloud, Smartphone, Globe, ArrowRight, Zap, Shield, TrendingUp, Code, Database, Cpu, BarChart3 } from "lucide-react";

const stats = [
  { value: "50+", label: "Projects Delivered" },
  { value: "98%", label: "Client Satisfaction" },
  { value: "12+", label: "Countries Served" },
  { value: "5+", label: "Years Experience" },
];

const services = [
  { icon: Code, title: "Custom Software", desc: "Enterprise-grade systems tailored to your business processes." },
  { icon: Brain, title: "AI & Machine Learning", desc: "Intelligent automation and predictive analytics solutions." },
  { icon: Smartphone, title: "Mobile Applications", desc: "Cross-platform mobile apps for iOS and Android." },
  { icon: Globe, title: "Web Development", desc: "Modern, fast, and responsive web platforms." },
];

const techIcons = [
  { icon: Cloud, label: "Cloud" },
  { icon: Brain, label: "AI/ML" },
  { icon: Database, label: "Data" },
  { icon: Cpu, label: "IoT" },
  { icon: Globe, label: "Web" },
  { icon: Smartphone, label: "Mobile" },
];

const whyUs = [
  { icon: Zap, title: "Speed", desc: "Rapid development with modern frameworks and agile methodology." },
  { icon: Shield, title: "Reliability", desc: "Enterprise-grade security and 99.9% uptime guarantees." },
  { icon: TrendingUp, title: "Growth", desc: "Scalable solutions that grow with your business needs." },
  { icon: BarChart3, title: "Data-Driven", desc: "Analytics-first approach to every solution we build." },
];

const testimonials = [
  { name: "David M.", role: "CEO, FinServ Africa", quote: "Cynite transformed our lending platform with AI-powered risk assessment. Our approval times dropped by 70%." },
  { name: "Grace K.", role: "CTO, Retail Plus", quote: "The e-commerce platform they built handles 10,000+ daily transactions flawlessly. Exceptional engineering." },
  { name: "Samuel O.", role: "Director, AgriTech Zambia", quote: "Their data analytics dashboard gave us visibility we never had before. Game-changing for our operations." },
];

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center pt-4 justify-center dot-pattern overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-primary/5 blur-3xl animate-glow-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-accent/5 blur-3xl animate-glow-pulse" style={{ animationDelay: "1.5s" }} />
        </div>

        <div className="container relative z-10 pt-24 pb-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className=" items-center hidden gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-xs text-muted-foreground mb-8 soft-shadow"
            >
              <span className="h-1.5 w-1.5 rounded-full gradient-bg" />
              Based in Lusaka, Zambia · Serving Africa & Beyond
            </motion.div>

            <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight leading-[1.1]">
              Building Intelligent{" "}
              <span className="gradient-text">Software</span>{" "}
              for the Future
            </h1>

            <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              We help businesses digitize operations, automate workflows, and leverage AI for growth. From enterprise software to machine learning systems.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="gradient" size="lg" asChild>
                <a 
                  href="mailto:mugwadiinnocent@gmail.com?subject=New%20Project%20Inquiry" 
                  className="inline-flex items-center"
                >
                  Start a Project <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button variant="gradient-outline" size="lg" asChild>
                <Link to="/services">View Services</Link>
              </Button>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6"
          >
            {stats.map((s, i) => (
              <div key={i} className="text-center p-6 rounded-lg bg-card border border-border soft-shadow">
                <div className="text-3xl md:text-4xl font-bold gradient-text">{s.value}</div>
                <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-24 bg-surface">
        <div className="container">
          <SectionHeading label="What We Do" title="Solutions That Drive Growth" description="From custom software to AI-powered automation, we build the technology your business needs to thrive." />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((s, i) => (
              <AnimatedCard key={i} delay={i * 0.1} className="group hover:bg-surface-hover transition-all">
                <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center mb-4">
                  <s.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold mb-2">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
                <Link to="/services" className="inline-flex items-center mt-4 text-sm text-primary font-medium hover:underline">
                  Learn more <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24">
        <div className="container">
          <SectionHeading label="Why Cynite" title="Built for Scale, Designed for Impact" description="We combine cutting-edge technology with deep industry understanding to deliver solutions that matter." />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyUs.map((w, i) => (
              <AnimatedCard key={i} delay={i * 0.1}>
                <div className="h-10 w-10 rounded-lg gradient-bg flex items-center justify-center mb-4">
                  <w.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold mb-2">{w.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{w.desc}</p>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-24 bg-surface">
        <div className="container">
          <SectionHeading label="Technology" title="Powered by Modern Tech" description="We use the latest technologies to build robust, scalable, and future-proof solutions." />
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="grid grid-cols-3 md:grid-cols-6 gap-6 max-w-3xl mx-auto"
          >
            {techIcons.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="flex flex-col items-center gap-2 p-4 rounded-lg bg-card border border-border soft-shadow hover:border-primary/30 transition-colors"
              >
                <t.icon className="h-8 w-8 text-primary" />
                <span className="text-xs text-muted-foreground font-medium">{t.label}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24">
        <div className="container">
          <SectionHeading label="Testimonials" title="Trusted by Industry Leaders" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <AnimatedCard key={i} delay={i * 0.1} gradient>
                <p className="text-sm text-muted-foreground leading-relaxed italic">"{t.quote}"</p>
                <div className="mt-4 pt-4 border-t border-border">
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-surface">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-2xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
              Ready to Build the <span className="gradient-text">Future</span>?
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Let's discuss how Cynite Technologies can transform your business with intelligent software solutions.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="gradient" size="lg" asChild>
                <a 
                  href="mailto:mugwadiinnocent@gmail.com?subject=New%20Project%20Inquiry" 
                  className="inline-flex items-center"
                >
                  Start a Project <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button variant="gradient-outline" size="lg" asChild>
              <a 
                href="tel:+2609883940" 
                className="hover:text-primary transition-colors"
              >
                Give us a call
              </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Index;
