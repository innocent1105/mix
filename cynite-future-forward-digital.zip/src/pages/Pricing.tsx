import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import SectionHeading from "@/components/SectionHeading";
import { Check, ArrowRight } from "lucide-react";

const tiers = [
  {
    name: "Starter",
    price: "From +$1,500",
    desc: "Perfect for small businesses looking to establish a digital presence.",
    features: ["Basic website or application", "Responsive design", "Up to 5 pages/screens", "Basic SEO optimization", "2 rounds of revisions", "30-day support"],
    highlighted: false,
  },
  {
    name: "Business",
    price: "From +$2,800",
    desc: "Comprehensive solutions for growing businesses with complex needs.",
    features: ["Full web platform or mobile app", "Custom UI/UX design", "API integrations", "Automation systems", "Database architecture", "Analytics dashboard", "90-day support", "Priority delivery"],
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    desc: "Tailored solutions for large organizations with advanced requirements.",
    features: ["Custom AI/ML systems", "Advanced integrations", "Dedicated project team", "24/7 support", "Performance optimization", "Security audits", "Scalable infrastructure", "SLA guarantee"],
    highlighted: false,
  },
];

const comparison = [
  { feature: "Custom Design", starter: true, business: true, enterprise: true },
  { feature: "Responsive Development", starter: true, business: true, enterprise: true },
  { feature: "API Integrations", starter: false, business: true, enterprise: true },
  { feature: "Database Design", starter: false, business: true, enterprise: true },
  { feature: "AI/ML Features", starter: false, business: false, enterprise: true },
  { feature: "Dedicated Team", starter: false, business: false, enterprise: true },
  { feature: "24/7 Support", starter: false, business: false, enterprise: true },
  { feature: "SLA Guarantee", starter: false, business: false, enterprise: true },
];

const Pricing = () => (
  <div className="min-h-screen pt-24">
    <section className="py-24 dot-pattern">
      <div className="container">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
          <span className="inline-block text-xs font-medium tracking-widest uppercase gradient-text mb-4">Pricing</span>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">Transparent <span className="gradient-text">Pricing</span></h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">Choose a plan that fits your needs, or request a custom quote for specialized projects.</p>
        </motion.div>
      </div>
    </section>

    {/* Tiers */}
    <section className="py-24 bg-surface">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {tiers.map((tier, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`rounded-lg p-6 border flex flex-col ${
                tier.highlighted
                  ? "gradient-border glow"
                  : "border-border bg-card soft-shadow"
              }`}
            >
              {tier.highlighted && (
                <span className="inline-block self-start text-xs font-medium gradient-bg text-primary-foreground rounded-full px-3 py-1 mb-4">Most Popular</span>
              )}
              <h3 className="text-xl font-bold">{tier.name}</h3>
              <p className="text-2xl font-bold gradient-text mt-2">{tier.price}</p>
              <p className="text-sm text-muted-foreground mt-2 mb-6">{tier.desc}</p>
              <ul className="space-y-3 mb-8 flex-1">
                {tier.features.map((f, j) => (
                  <li key={j} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <Check className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button variant={tier.highlighted ? "gradient" : "gradient-outline"} asChild>
                <Link to="/contact">Get Started</Link>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <section className="py-24">
      <div className="container max-w-4xl">
        <SectionHeading label="Compare" title="Feature Comparison" />
        <div className="rounded-lg border border-border overflow-hidden soft-shadow">
          <div className="grid grid-cols-4 gap-0 text-sm">
            <div className="p-4 font-semibold border-b border-border bg-surface">Feature</div>
            {["Starter", "Business", "Enterprise"].map((t) => (
              <div key={t} className="p-4 font-semibold border-b border-border bg-surface text-center">{t}</div>
            ))}
            {comparison.map((row, i) => (
              <>
                <div key={`f-${i}`} className="p-4 text-muted-foreground border-b border-border/50">{row.feature}</div>
                {[row.starter, row.business, row.enterprise].map((val, j) => (
                  <div key={`v-${i}-${j}`} className="p-4 text-center border-b border-border/50">
                    {val ? <Check className="h-4 w-4 text-primary mx-auto" /> : <span className="text-muted-foreground/30">—</span>}
                  </div>
                ))}
              </>
            ))}
          </div>
        </div>
      </div>
    </section>

    <section className="py-24 bg-surface">
      <div className="container text-center max-w-2xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="text-3xl font-bold">Need Something <span className="gradient-text">Custom</span>?</h2>
          <p className="mt-4 text-muted-foreground">Every project is unique. Let's discuss your specific requirements and create a tailored proposal.</p>
          <Button variant="gradient" size="lg" className="mt-8" asChild>
            <Link to="/contact">Request Custom Quote <ArrowRight className="ml-2 h-4 w-4" /></Link>
          </Button>
        </motion.div>
      </div>
    </section>
  </div>
);

export default Pricing;
