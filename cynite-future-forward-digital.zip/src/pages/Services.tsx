import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import SectionHeading from "@/components/SectionHeading";
import { Code, Brain, Smartphone, Globe, ArrowRight, Database, Zap, BarChart3, Layers, ShoppingCart } from "lucide-react";

const services = [
  {
    icon: Code,
    title: "Custom Software Development",
    desc: "We design and build enterprise-grade software tailored to your unique business processes, from internal tools to customer-facing platforms.",
    benefits: ["Streamlined operations", "Reduced manual processes", "Scalable architecture"],
    useCases: ["Enterprise resource planning (ERP)", "SaaS platforms", "Business process automation"],
    subServices: [
      { icon: Database, label: "Enterprise Systems" },
      { icon: Layers, label: "SaaS Platforms" },
      { icon: Zap, label: "Business Automation" },
    ],
  },
  {
    icon: Brain,
    title: "AI & Machine Learning",
    desc: "Harness the power of artificial intelligence to automate decisions, predict trends, and unlock insights from your data.",
    benefits: ["Predictive decision-making", "Automated workflows", "Data-driven insights"],
    useCases: ["Predictive analytics", "AI-powered automation", "Data intelligence systems"],
    subServices: [
      { icon: BarChart3, label: "Predictive Analytics" },
      { icon: Zap, label: "AI Automation" },
      { icon: Database, label: "Data Intelligence" },
    ],
  },
  {
    icon: Smartphone,
    title: "Mobile App Development",
    desc: "Build beautiful, high-performance mobile applications for iOS and Android that your users will love.",
    benefits: ["Native performance", "Cross-platform reach", "Offline capabilities"],
    useCases: ["Consumer apps", "Enterprise mobile tools", "On-demand service platforms"],
    subServices: [
      { icon: Smartphone, label: "Android Apps" },
      { icon: Smartphone, label: "iOS Apps" },
      { icon: Layers, label: "Cross-Platform" },
    ],
  },
  {
    icon: Globe,
    title: "Web Development",
    desc: "Modern, fast, and responsive web applications and platforms built with the latest technologies and best practices.",
    benefits: ["Lightning-fast performance", "SEO optimized", "Responsive design"],
    useCases: ["Corporate websites", "Web applications", "E-commerce platforms"],
    subServices: [
      { icon: Globe, label: "Modern Websites" },
      { icon: Layers, label: "Web Platforms" },
      { icon: ShoppingCart, label: "E-Commerce" },
    ],
  },
];

const Services = () => (
  <div className="min-h-screen pt-24">
    {/* Hero */}
    <section className="py-24 dot-pattern">
      <div className="container">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="max-w-3xl">
          <span className="inline-block text-xs font-medium tracking-widest uppercase gradient-text mb-4">Our Services</span>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.1]">
            End-to-End <span className="gradient-text">Technology</span> Solutions
          </h1>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed max-w-2xl">
            From concept to deployment, we build intelligent software solutions that transform how businesses operate and grow.
          </p>
        </motion.div>
      </div>
    </section>

    {/* Services */}
    <section className="py-12">
      <div className="container space-y-20">
        {services.map((service, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className={`grid grid-cols-1 lg:grid-cols-2 gap-8 py-12 border-t border-border`}
          >
            <div>
              <div className="h-12 w-12 rounded-lg gradient-bg flex items-center justify-center mb-4">
                <service.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">{service.title}</h2>
              <p className="text-muted-foreground leading-relaxed mb-6">{service.desc}</p>
              <div className="flex gap-3 flex-wrap">
                {service.subServices.map((sub, j) => (
                  <div key={j} className="flex items-center gap-2 text-xs rounded-full border border-border bg-card px-3 py-1.5 text-muted-foreground soft-shadow">
                    <sub.icon className="h-3 w-3" />
                    {sub.label}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="rounded-lg border border-border bg-card p-5 soft-shadow">
                <h4 className="text-sm font-semibold mb-3 text-primary">Key Benefits</h4>
                <ul className="space-y-2">
                  {service.benefits.map((b, j) => (
                    <li key={j} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="mt-1.5 h-1.5 w-1.5 rounded-full gradient-bg flex-shrink-0" />
                      {b}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-lg border border-border bg-card p-5 soft-shadow">
                <h4 className="text-sm font-semibold mb-3 text-primary">Use Cases</h4>
                <ul className="space-y-2">
                  {service.useCases.map((u, j) => (
                    <li key={j} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="mt-1.5 h-1.5 w-1.5 rounded-full gradient-bg flex-shrink-0" />
                      {u}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>

    {/* CTA */}
    <section className="py-24 bg-surface">
      <div className="container text-center max-w-2xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Need a <span className="gradient-text">Custom Solution</span>?</h2>
          <p className="mt-4 text-muted-foreground mb-8">Let's discuss your project requirements and find the perfect technology fit.</p>
          <Button variant="gradient" size="lg" asChild>
            <a 
              href="mailto:mugwadiinnocent@gmail.com?subject=New%20Project%20Inquiry" 
              className="inline-flex items-center"
            >
              Get a quote <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  </div>
);

export default Services;
