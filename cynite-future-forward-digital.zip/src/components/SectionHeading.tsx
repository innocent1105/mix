import { motion } from "framer-motion";

interface SectionHeadingProps {
  label?: string;
  title: string;
  description?: string;
  className?: string;
  center?: boolean;
}

const SectionHeading = ({ label, title, description, className = "", center = true }: SectionHeadingProps) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5 }}
    className={`mb-12 ${center ? "text-center flex-col justify-center " : ""} ${className}`}
  >
    {label && (
      <span className="inline-block text-xs font-medium tracking-widest gradient-text mb-3">
        {label}
      </span>
    )}
    <h2 className="text-3xl md:text-4xl font-bold tracking-tight">{title}</h2>
    {description && (
      <div className="mt-4 text-muted-foreground w-full leading-relaxed ">{description}</div>
    )}
  </motion.div>
);

export default SectionHeading;
