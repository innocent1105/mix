import { motion } from "framer-motion";
import { ReactNode } from "react";

interface AnimatedCardProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  gradient?: boolean;
}

const AnimatedCard = ({ children, className = "", delay = 0, gradient = false }: AnimatedCardProps) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay }}
    className={`rounded-lg bg-card p-6 border border-border soft-shadow hover:shadow-md transition-all ${gradient ? "gradient-border" : ""} ${className}`}
  >
    {children}
  </motion.div>
);

export default AnimatedCard;
