import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="border-t border-border bg-card">
    <div className="container py-16">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
        <div className="md:col-span-1">
          <Link to="/" className="font-heading text-xl font-bold tracking-tight">
            <span className="gradient-text">Cynite technologies.inc</span>
          </Link>
          <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
            Building intelligent software for businesses in Africa and globally.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-4">Company</h4>
          <div className="flex flex-col gap-2">
            {["About", "Services", "Projects", "Pricing"].map((l) => (
              <Link key={l} to={`/${l.toLowerCase()}`} className="text-sm text-muted-foreground hover:text-foreground transition-colors">{l}</Link>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-4">Services</h4>
          <div className="flex flex-col gap-2">
            {["Custom Software", "AI & ML", "Mobile Apps", "Web Development"].map((s) => (
              <Link key={s} to="/services" className="text-sm text-muted-foreground hover:text-foreground transition-colors">{s}</Link>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-4">Contact</h4>
          <div className="flex flex-col gap-2 text-sm text-muted-foreground">
            <span>hello@cynite.tech</span>
            <span>Lusaka, Zambia</span>
            <Link to="/contact" className="hover:text-foreground transition-colors">Get in Touch →</Link>
          </div>
        </div>
      </div>

      <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Cynite Technologies. All rights reserved.</p>
        <div className="flex gap-6">
          <span className="text-xs text-muted-foreground">Privacy Policy</span>
          <span className="text-xs text-muted-foreground">Terms of Service</span>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
