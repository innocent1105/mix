// UserMap.js
import React, { useEffect, useRef,useMemo, useState } from "react";
import { View, Platform, Text,ScrollView,  KeyboardAvoidingView, Image,ActivityIndicator, Keyboard  ,Dimensions,Modal } from "react-native";
import { WebView } from "react-native-webview";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import * as Location from "expo-location";
import Ionicons from '@expo/vector-icons/Ionicons';
import Octicons from '@expo/vector-icons/Octicons';
import Feather from '@expo/vector-icons/Feather';
import AntDesign from '@expo/vector-icons/AntDesign';
import FontAwesome from "@expo/vector-icons/FontAwesome";
import Entypo from '@expo/vector-icons/Entypo';
import { TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import axios from "axios";
import * as SecureStore from 'expo-secure-store';
import { TextInput } from "react-native-gesture-handler";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { format, formatDistanceToNow } from "date-fns";
import { RefreshControl } from "react-native";

import BottomNav from "./components/BottomNav";
import HomeScreenHeader from "./components/HomeScreenHeader";

const saveToStorage = async (key, data) => {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error("Error saving to storage:", err);
  }
};

const loadFromStorage = async (key) => {
  try {
    const value = await AsyncStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch (err) {
    console.error("Error loading from storage:", err);
    return null;
  }
};

export default function HomeScreen() {
  const navigation = useNavigation();
  const [mapLoading, setMapLoading] = useState(false);

  const loadUserId = async () => {
    try {
      let user_id = await SecureStore.getItemAsync('id');
      if(user_id && user_id.length > 2) {
        console.log("User ID:", user_id);
  
        return user_id;
      } else {
        console.log("No user ID found in storage");
        navigation.replace("Onboarding");
      }
    } catch (error) {
      console.error("Error reading user_id from storage:", error);
      navigation.replace("Login");
    }
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return formatDistanceToNow(date, { addSuffix: true });
  };

  useEffect(() => {
    const fetchUserId = async () => {
      const id = await loadUserId();
      if (id) {
        console.log("Loaded user ID:", id);
      }
    };
  
    fetchUserId();
  }, []);

  let server_api_base_url = "https://www.textiepro.xyz/";

  const [visible, setVisible] = useState(false);
  const [tab, setTab] = useState("none");

  const [image, setImage] = useState(null);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      alert("Permission required to access gallery!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.7,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };
  const [user_id, setUserId] = useState("");
  const loadUser = async () => {
    const id = await SecureStore.getItemAsync('id');

    if (id) setUserId(id);
  };


  useEffect(() => {
    loadUser();
  }, []);

  const { width } = Dimensions.get("window");


  const webviewRef = useRef(null);
  const [mapReady, setMapReady] = useState(false);
  const [pendingLocation, setPendingLocation] = useState(null);
  const [pinnedLocation, setPinnedLocation] = useState(null);
  const [users, setUsers] = useState([]);


  const [pins, setPins] = useState([]);
  const [PinInView, setPinInView] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const fetchPins = async () => {
      try {
        const cachedPins = await loadFromStorage("pins");
        if (cachedPins) {
          setPins(cachedPins);
          console.log("Loaded pins from storage:", cachedPins);
        }
  
        const res = await axios.post(`${server_api_base_url}get_pins.php`, {
          headers: {
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (ReactNative)"
          }, 
        });
  
        if (res.headers["content-type"]?.includes("application/json")) {
          setPins(res.data);
          setRefreshing(false);
          await saveToStorage("pins", res.data); // save locally
          console.log("Fetched and saved pins:", res.data);
        }
      } catch (err) {
        console.error("Fetch error:", err);
      }
    };
  
    fetchPins();
    const interval = setInterval(fetchPins, 100000);
    return () => clearInterval(interval);
  }, []);
  






  const getUsersUrl = server_api_base_url + "geo_users.php";


  useEffect(() => {
    const fetchUsers = async () => {
      try {

        const cachedUsers = await loadFromStorage("users");
        if (cachedUsers) {
          setUsers(cachedUsers);
          console.log("Loaded users from storage:", cachedUsers);
        }
        const res = await axios.post(getUsersUrl, { user_id });
        if (res.data && Array.isArray(res.data)) {
          setUsers(res.data);
          await saveToStorage("users", res.data); 
          console.log("Fetched and saved users:", res.data);
        }
      } catch (err) {
        console.log("Error fetching users:", err);
      }
    };
  
    fetchUsers();
  }, [user_id]);
  



  

  const [address, setAddress] = useState(null);
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [lng, setLng] = useState("");
  const [lat, setLat] = useState("");

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted"){
          console.warn("Location permission denied");
          return;
        }
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
  
        const { latitude, longitude } = loc.coords;
        setPendingLocation({ latitude, longitude });

        setLng(longitude)
        setLat(latitude) 


        const geo = await Location.reverseGeocodeAsync({ latitude, longitude });
        if (!mounted) return;
  
        if (geo.length > 0) {
          setAddress({
            user_id: user_id,
            country: geo[0].country,
            province: geo[0].region,
            region: geo[0].region,
            city: geo[0].city,
            postalCode: geo[0].postalCode,
            street: geo[0].street,
            lng : longitude,
            lat : latitude
          });
          

          if(latitude !== null){
            try{
              const response = await axios.post(
                server_api_base_url + "save_coordinates.php",{
                  "address" : address
                },{
                  headers: {
                    "Content-Type": "application/json",
                  },
                }
              );
  
              console.log(response.data)
            }catch(err){
              console.log("error :", err)
            }
          }

          console.log(address)
        }

      } catch (e) {
        console.warn("Location error:", e);
      }
    })();
    return () => { mounted = false; };
  }, []);


  useEffect(() => {
    if (mapReady && pendingLocation && webviewRef.current) {
      const { latitude, longitude } = pendingLocation;
      try {
        const js = `window.setRNLocation(${latitude}, ${longitude}); true;`;
        webviewRef.current.injectJavaScript(js);
      } catch (e) {
        // fallback: send as postMessage (some RN/WebView versions prefer this)
        try {
          webviewRef.current.postMessage(JSON.stringify({ type: 'location', lat: latitude, lng: longitude }));
        } catch (err) {
          console.warn("Could not send location to WebView", err);
        }
      }
    }
  }, [mapReady, pendingLocation]);



  const [clickedUser, setCUser] = useState(null)

  const [clickedUserPins, setCUPins] = useState([]);
  const [noUserPins, setNoUserPins] = useState(false);
  const getUserPins = async (id)=>{
    setCUPins([]);
    try{
      const res = await axios.post(`${server_api_base_url}get_user_pins.php`, {"user_id" : id});
      setCUPins(res.data);
      console.log(res.data);
      if(res.data.length === 0){
        setNoUserPins(true);
      }
    }catch(e){
      console.log("Error")
    }
 
  }


  const [keyboardVisible, setKeyboardVisible] = useState(false);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setKeyboardVisible(true)
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => setKeyboardVisible(false)
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);
 

const handleRefresh = async () => {
  setRefreshing(true);
  await fetchPins(); 
  setRefreshing(false);
};


  

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
     <HomeScreenHeader navigation={navigation} />


    <ScrollView 
      showsVerticalScrollIndicator={false} 
      className="p-1 mt-24"
      contentContainerStyle={{ paddingBottom: 170 }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          colors={["#808080"]}
          tintColor="#808080"
        />
      }
    >
      {pins.length === 0 ? (
        <View className="items-center justify-center py-10">
          <ActivityIndicator size="large" color="#888" />
          <Text className="text-gray-400 mt-2">Loading posts...</Text>
        </View>
      ) : (
        pins.map((pin, index) => (
          <View key={index} className="mb-4 p-3 rounded-2xl bg-white shadow">
            <View className="flex-row justify-between mb-2">
              <TouchableOpacity onPress={()=>{}} activeOpacity={0.5} className="flex-row items-center">
                <Image
                  source={{ uri: `${server_api_base_url}view_pp.php?file=${pin.profile}`  }}
                  className="w-10 h-10 rounded-full mr-3"
                />
                <View>
                  <Text className="font-semibold text-base">{pin.username}</Text>
                  <Text className="text-gray-500 text-xs">
                    {formatDate(pin.date_created)}
                  </Text>
                </View>
              </TouchableOpacity>
              <View className =" ">
                <TouchableOpacity
                  onPress={() => {}}
                  className="p-2 rounded-lg "
                >
                  <Entypo name="dots-three-horizontal" size={20} color="#555" />
                </TouchableOpacity>
              </View>
            </View>

            <Text className="font-semibold text-lg mb-1">
              {pin.name}
            </Text>
            {pin.description ? (
              <Text className="text-gray-500 mb-2">{pin.description}</Text>
            ) : null}

             { pin.tag && pin.tag !== "null" && pin.tag.length !== 0 ? (
              <Text className="text-blue-700 font-semibold mb-2">{pin.tag}</Text>
            ) : null}

            {pin.images && (
              <TouchableOpacity onPress={() => 
                {
                 navigation.navigate("OpenPost", { PinInView: pin });
                }} 
                activeOpacity={0.9}
              >
                <Image
                  source={{ uri: `${server_api_base_url}view_image.php?file=${pin.images}`}}
                  className="w-full h-[400] rounded-xl mb-2"
                  resizeMode="cover"
                />
              </TouchableOpacity>
            )}

            <View className="">
              <View className="flex-row justify-around px-1 ">
                <TouchableOpacity className="flex-row justify-center p-2 rounded-full items-center bg-gray-100">
                  <FontAwesome name="heart" size={22} color="#aaa" />
                    <Text className="px-1 font-semibold text-gray-500">
                      {pin.likes === 0
                        ? "No Likes"
                        : pin.likes === 1
                        ? "1 Like"
                        : pin.likes >= 1000000
                        ? `${(pin.likes / 1000000).toFixed(1)}M Likes`
                        : pin.likes >= 1000
                        ? `${(pin.likes / 1000).toFixed(1)}K Likes`
                        : `${pin.likes} Likes`}
                    </Text>

                </TouchableOpacity>

                <View className="flex-row justify-center p-2 rounded-full items-center bg-gray-100">
                  <Ionicons name="chatbubble-sharp" size={24} color="#aaa" />
                  <Text className="font-semibold text-gray-600">
                    {pin.comments === 0
                      ? "Comment here"
                      : pin.comments === 1
                      ? "1 Comment"
                      : pin.comments >= 1000000
                      ? `${(pin.comments / 1000000).toFixed(1)}M Comments`
                      : pin.comments >= 1000
                      ? `${(pin.comments / 1000).toFixed(1)}K Comments`
                      : `${pin.comments} Comments`
                    }
                  </Text>
                </View>

                <View className="flex-row justify-center p-2 rounded-full items-center bg-gray-50">
                  <Feather name="eye" size={24} color="#9ca3af" />
                
                  <Text className="px-1 font-semibold text-gray-400">
                    {pin.views === 0
                      ? "First viewer"
                      : pin.views === 1
                      ? "1 View"
                      : pin.views >= 1000000
                      ? `${(pin.views / 1000000).toFixed(1)}M`
                      : pin.views >= 1000
                      ? `${(pin.views / 1000).toFixed(1)}K`
                      : `${pin.views}`}
                  </Text>

                </View>
              </View>

            </View>

          </View>
        ))
      )}

      <View className ="  p-4 mb-40">
        <Text className="pl-3 pb-4 text-gray-500">
          You can explore more posts from people around the world or see those
          near you.
        </Text>

        <TouchableOpacity
          onPress={() => navigation.navigate("Map")}
          className="bg-gray-200 flex flex-row rounded-full p-3 items-center"
        >
          <Ionicons name="location-sharp" size={24} color="#555" />
          <Text className="pl-2 text-gray-500">See people near me</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>

   

   

          









      {tab == "none" && (
        <BottomNav screen={"Home"} navigation={navigation}/>
      )}
      


    </GestureHandlerRootView>
  );
}