import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  RefreshControl,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ImageBackground,
  Image,
} from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import Feather from "@expo/vector-icons/Feather";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import HomeScreenHeader from "./components/HomeScreenHeader";
import * as SecureStore from "expo-secure-store";
import axios from "axios";
import { formatDistanceToNow } from "date-fns";
import PostComments from "./components/PostComments";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

const loadUserId = async () => {
  try {
    let user_id = await SecureStore.getItemAsync("id");
    if (user_id) {
      console.log("User ID:", user_id);
      return user_id;
    } else {
      console.log("No user ID found in storage");
      return null;
    }
  } catch (error) { 
    console.error("Error reading user_id from storage:", error);
  }
};

const formatDate = (dateString) => {
  const date = new Date(dateString);
  return formatDistanceToNow(date, { addSuffix: true });
};

export default function UserProfile({ route, navigation }) {

  const [user_id, setUserId] = useState(null);

  const [refreshing, setRefreshing] = useState(false);

  const server_api_base_url = "https://www.textiepro.xyz/";

  useEffect(() => {
    const fetchUserId = async () => {
      const id = await loadUserId();
      if (id) setUserId(id);
    };
    fetchUserId();
  }, []);




  


  

  const onRefresh = useCallback(() => {
    setRefreshing(true);
   
  }, [user_id]);

  const handleRefresh = async () => {
    setRefreshing(true);
  
  };



  return (
    <KeyboardAwareScrollView
      style={{ flex: 1, backgroundColor: "white" }}
      contentContainerStyle={{ flexGrow: 1 }}
      enableOnAndroid={true}
      extraScrollHeight={300}
      keyboardShouldPersistTaps="handled"
    >
      <HomeScreenHeader screen={"profile"} />

        <ScrollView 
            showsVerticalScrollIndicator={false} 
            className=" mt-24 bg-gray-100"
            contentContainerStyle={{ paddingBottom: 170 }}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={handleRefresh}
                colors={["#808080"]}
                tintColor="#808080"
              />
            }
          >
          

         

            <ImageBackground
                source={require("../../assets/images/chatbg3.jpg")}
                resizeMode="cover"
                className="p-4 pt-20 flex flex-row justify-between border border-gray-200"
                >
                <View className="flex flex-row">
                    <View className="">
                    <Image
                        source={{ uri: `${server_api_base_url}view_pp.php?file=default-pp.png` }}
                        className="w-20 h-20 rounded-xl mb-2 object-cover"
                        resizeMode="cover"
                    />
                    </View>

                    <View className=" ml-2 flex flex-col justify-end pb-2">
                        <Text className="text-xl font-bold text-gray-800">John Doe</Text>
                        <Text className="text-gray-700 text-sm">@johndoe</Text>
                    </View>
                </View>
            </ImageBackground>


          
        
        </ScrollView>

   </KeyboardAwareScrollView>
  );
}
