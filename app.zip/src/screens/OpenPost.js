import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  RefreshControl,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Image,
} from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import Feather from "@expo/vector-icons/Feather";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import HomeScreenHeader from "./components/HomeScreenHeader";
import * as SecureStore from "expo-secure-store";
import axios from "axios";
import { formatDistanceToNow } from "date-fns";
import PostComments from "./components/PostComments";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

const loadUserId = async () => {
  try {
    let user_id = await SecureStore.getItemAsync("id");
    if (user_id) {
      console.log("User ID:", user_id);
      return user_id;
    } else {
      console.log("No user ID found in storage");
      return null;
    }
  } catch (error) { 
    console.error("Error reading user_id from storage:", error);
  }
};

const formatDate = (dateString) => {
  const date = new Date(dateString);
  return formatDistanceToNow(date, { addSuffix: true });
};

export default function OpenPost({ route, navigation }) {
  const { PinInView } = route.params;

  const [user_id, setUserId] = useState(null);
  const [pinLikes, setPinLikes] = useState(PinInView.likes);
  const [liked, setLiked] = useState(false);
  const [comments, setComments] = useState([]);
  const [loadingComments, setLoadingComments] = useState(true);
  const [comment, setComment] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const server_api_base_url = "https://www.textiepro.xyz/";

  useEffect(() => {
    const fetchUserId = async () => {
      const id = await loadUserId();
      if (id) setUserId(id);
    };
    fetchUserId();
  }, []);


  const likePost = async (post_id) => {
    if (!liked) {
      setPinLikes(pinLikes + 1);
      setLiked(true);
    } else {
      setPinLikes(pinLikes - 1);
      setLiked(false);
    }

    try {
      const user_id = await SecureStore.getItemAsync("id"); 
  
      const res = await axios.post(`${server_api_base_url}like.php`, {
        user_id,
        post: post_id,
      });
  
      if (res.data.status === "liked") {
        console.log("Post liked!");
      } else if (res.data.status === "unliked") {
        console.log("Post unliked!");
      }
    } catch (error) {
      console.error("Like error:", error.response?.data || error.message);
    }
  };

  

  const fetchComments = async (postId, userId) => {
    try {
      const res = await axios.post(`${server_api_base_url}load_comments.php`, {
        user_id: userId,
        post_id: postId,
      });
      setComments(res.data);
      setLoadingComments(false);
      setRefreshing(false);
    } catch (e) {
      console.log("Error fetching comments:", e);
    }
  };

  const fetchLikes = async (postId, userId) => {
    try {
      const res = await axios.post(`${server_api_base_url}load_likes.php`, {
        user_id: userId,
        post_id: postId,
      });

      if(res.data.likes){
        setPinLikes(res.data.likes);
        setLiked(res.data.isLiked);
      }
      
      // setPinLikes(res.data);
      setRefreshing(false);

      console.log(res.data)
    } catch (e) {
      console.log("Error fetching likes:", e);
    }
  };

  useEffect(() => {
    if (user_id) fetchComments(PinInView.id, user_id);
    if (user_id) fetchLikes(PinInView.id, user_id);
  }, [user_id]);

  const postComment = async (id, postId, commentText) => {
    try {
      const res = await axios.post(`${server_api_base_url}comment.php`, {
        user_id: id,
        post_id: postId,
        comment: commentText,
      });

      if (res.data === "success") {
        fetchComments(PinInView.id, user_id);
        return true;
      }
      return false;
    } catch (e) {
      console.log("Error posting comment:", e);
      return false;
    }
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchLikes(PinInView.id, user_id);
    fetchComments(PinInView.id, user_id);
  }, [user_id]);

  return (
    <KeyboardAwareScrollView
      style={{ flex: 1, backgroundColor: "white" }}
      contentContainerStyle={{ flexGrow: 1 }}
      enableOnAndroid={true}
      extraScrollHeight={300}
      keyboardShouldPersistTaps="handled"
    >
      <HomeScreenHeader screen={"open_post"} />

      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: 100 }}
        className="mt-24 border-t h-2 border-gray-200"
      >
   
        <View
          style={{ flexDirection: "row", alignItems: "center", padding: 15 }}
          className="px-2 pt-2 pb-2"
        >
          <Image
            source={{
              uri: `https://www.textiepro.xyz/view_pp.php?file=${PinInView.profile}`,
            }}
            style={{
              width: 50,
              height: 50,
              borderRadius: 25,
              marginRight: 10,
            }}
          />
          <View>
            <Text style={{ fontSize: 16, fontWeight: "600" }}>
              {PinInView.username}
            </Text>
            <Text style={{ color: "gray", fontSize: 12 }}>
              {new Date(PinInView.date).toDateString()}
            </Text>
          </View>
        </View>

        <View className="p-1 px-3">
          <Text className="text-sm font-bold text-gray-900">
            {PinInView.name}
          </Text>
          <Text className="text-sm text-gray-600">{PinInView.des} </Text>
          <Text className="text-sm text-gray-600">
            {PinInView.tag && `#${PinInView.tag.replace(/,/g, " #")}`} 
          </Text>
        </View>

        <Image
          source={{
            uri: `https://www.textiepro.xyz/view_image.php?file=${PinInView.images}`,
          }}
          style={{ width: "100%", height: "auto", aspectRatio: 1 }}
          resizeMode="cover"
        />

        <View className="flex-row justify-around py-2 px-1 border-t border-b border-gray-200">
          <TouchableOpacity
            onPress={()=>{likePost(PinInView.id)}}
            className={`flex-row justify-center p-2 rounded-full items-center ${
              liked ? "bg-red-100" : "bg-gray-100"
            }`}
          >
            <FontAwesome
              name="heart"
              size={22}
              color={pinLikes > 0 ? "red" : "#aaa"}
            />
              <Text className="px-1 font-semibold text-gray-500">
                {PinInView.likes === 0
                  ? "No Likes"
                  : PinInView.likes === 1
                  ? "1 Like"
                  : PinInView.likes >= 1000000
                  ? `${(pin.likes / 1000000).toFixed(1)}M Likes`
                  : PinInView.likes >= 1000
                  ? `${(PinInView.likes / 1000).toFixed(1)}K Likes`
                  : `${PinInView.likes} Likes`}
              </Text>

          </TouchableOpacity>

          <View
            className={`flex-row justify-center p-2 rounded-full items-center ${
              PinInView.comments > 0 ? "bg-purple-100" : "bg-gray-100"
            }`}
          >
            <Ionicons
              name="chatbubble-sharp"
              size={24}
              color={PinInView.comments > 0 ? "#7B68EE" : "#aaa"}
            />
              <Text className="font-semibold text-gray-600">
              {PinInView.comments === 0
                ? "Add Comment"
                : PinInView.comments === 1
                ? "1 Comment"
                : PinInView.comments >= 1000000
                ? `${(pin.comments / 1000000).toFixed(1)}M Comments`
                : PinInView.comments >= 1000
                ? `${(PinInView.comments / 1000).toFixed(1)}K Comments`
                : `${PinInView.comments} Comments`
              }
            </Text>
          </View>

          <View className="flex-row justify-center p-2 rounded-full items-center bg-gray-50">
            <Feather name="eye" size={24} color="#9ca3af" />
            <Text className="px-1 font-semibold text-gray-400">
              {PinInView.views}
            </Text>
          </View>
        </View>

        {loadingComments ? (
          <View className="mt-10">
            <Text className="text-center text-gray-500 font-semibold">
              Loading comments...
            </Text>
          </View>
        ) : (
          <PostComments comments={comments} />
        )}
      </ScrollView>

      <View className="flex-row items-center border-t border-gray-200 px-3 py-2 bg-white">
        <TextInput
          value={comment}
          onChangeText={setComment}
          placeholder="Write a comment..."
          placeholderTextColor="#9ca3af"
          className="flex-1 px-3 py-2 rounded-xl bg-gray-100 text-gray-800"
        />
        <TouchableOpacity
          onPress={() => {
            if (comment.trim().length > 0) {
              postComment(user_id, PinInView.id, comment);
              setComment("");
            }
          }}
          className="ml-2 bg-blue-500 px-4 py-2 rounded-xl"
        >
          <Text className="text-white font-semibold">Post</Text>
        </TouchableOpacity>
      </View>
      <View className =" pb-10"></View>
    </KeyboardAwareScrollView>
  );
}
