import React from "react";
import { View, Text, FlatList,RefreshControl, TouchableOpacity, ScrollView, Image } from "react-native";
import Ionicons from '@expo/vector-icons/Ionicons';
import Octicons from '@expo/vector-icons/Octicons';
import Entypo from '@expo/vector-icons/Entypo';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import Feather from '@expo/vector-icons/Feather';
import AntDesign from '@expo/vector-icons/AntDesign';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import Foundation from '@expo/vector-icons/Foundation';

import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useNavigation } from "@react-navigation/native";
export default function HomeScreenHeader({ screen }) {
    const navigation = useNavigation();

    return (
        <View className=" absolute flex flex-row justify-between left-0 right-0 top-0 bg-white p-4 pb-0 pt-12">
            {screen == "open_post" ? (
                <View className =" flex-row">
                    <TouchableOpacity  onPress={() => navigation.goBack()} className=" pt-1 mr-2 rounded-md">
                        <Octicons name="arrow-left" size={24} color="black" />
                    </TouchableOpacity> 
                    <Text className =" text-2xl font-bold">Post</Text>
                </View>
            ) : screen == "profile" ?(
                <Text className =" text-2xl font-bold">Profile</Text>
            ) : (
                <Text className =" text-2xl font-bold">Discover</Text>
            )}

            <View className=" flex flex-row justify-end">
           
        
            {/* <TouchableOpacity className=" p-2 rounded-md">
                <View className="  absolute p-1 ml-6 mt-2 rounded-full bg-red-500 z-40">
                </View>
                <Feather name="bell" size={24} color="black" />
            </TouchableOpacity> */}

            <TouchableOpacity className=" p-2 rounded-md">
                <View className="  absolute p-1 ml-6 mt-2 rounded-full bg-red-500 z-40">
                </View>
                <FontAwesome6 name="coins" size={24} color="black" />
            </TouchableOpacity>

            <TouchableOpacity onPress={()=>{navigation.navigate("UserProfile")}} className="p-2 rounded-md">
                <View className="  absolute p-1 ml-6 mt-2 rounded-full bg-red-500 z-40">
                </View>
                <FontAwesome6 name="circle-user" size={24} color="black" />
            </TouchableOpacity>
            
       

            </View>

        </View>
    );
      
}
