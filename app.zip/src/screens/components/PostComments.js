import React from "react";
import { View, Text, FlatList, TouchableOpacity, ScrollView, Image } from "react-native";
import Ionicons from '@expo/vector-icons/Ionicons';
import Octicons from '@expo/vector-icons/Octicons';
import Entypo from '@expo/vector-icons/Entypo';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import Feather from '@expo/vector-icons/Feather';
import AntDesign from '@expo/vector-icons/AntDesign';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import Foundation from '@expo/vector-icons/Foundation';
import axios from "axios";
import { format, formatDistanceToNow } from "date-fns";
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

const formatDate = (dateString) => {
    const date = new Date(dateString);
    return formatDistanceToNow(date, { addSuffix: true });
};

export default function PostComments({ screen, navigation, comments }) {
    let server_api_base_url = "https://www.textiepro.xyz/";
    

    return (
        <View className="  bg-white pb-20">
          {comments.length > 0 ? (
            comments.map((c, index) => (
            <TouchableOpacity
                key={c.comment_id || index}
                className="  px-1 rounded-lg bg-white"
            >
        
                <View className =" flex-row">
                    <TouchableOpacity className="rounded-lg p-2 flex flex-row justify-between">
                        <View className="flex flex-row">
                            <Image 
                            source={{ uri: `${server_api_base_url}view_pp.php?file=${c.pp}` }}
                            className="h-10 w-10 border mr-1 rounded-full bg-gray-200"
                            />
                            <View>
                        
                            </View>
                        </View>

                    
                    </TouchableOpacity>

                    <View className =" flex-row w-4/5">
                        <View className="  bg-gray-200 rounded-xl p-2 px-3 mt-3">
                            <Text className="font-semibold">  
                                {c.username}
                            </Text>
                            <Text className="text-sm text-gray-600">{c.comment}</Text>

                            <View className =" mt-2 flex-row">
                                <TouchableOpacity className =" px-1">
                                    <Text className=" font-semibold text-gray-500">React</Text>
                                </TouchableOpacity>
                                <TouchableOpacity className =" px-1">
                                    <Text className=" font-semibold text-gray-500">Reply</Text>
                                </TouchableOpacity>
                                <TouchableOpacity className =" px-1">
                                    <Text className=" font-semibold text-gray-400">Hide</Text>
                                </TouchableOpacity>

                            </View>
                        </View>
                    </View>
                    
                </View>

                

            </TouchableOpacity>
            ))
        ) : (
            <Text className="text-center text-gray-400 mt-6">No comments yet</Text>
        )}

        </View>
    );
      
}
