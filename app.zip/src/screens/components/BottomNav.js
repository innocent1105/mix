import React from "react";
import { View, Text, FlatList, TouchableOpacity, ScrollView, Image } from "react-native";
import Ionicons from '@expo/vector-icons/Ionicons';
import Octicons from '@expo/vector-icons/Octicons';
import Entypo from '@expo/vector-icons/Entypo';

import Feather from '@expo/vector-icons/Feather';


export default function BottomNav({ screen, navigation }) {
 

    return (
        <View
          className={`absolute bottom-0 left-0 right-0 p-2 pb-14 bg-white border-t border-gray-100`}
        >
          <View
            className={`p-2 px-6 w-full bg-gray-100 rounded-full flex flex-row items-center
              ${screen === "Home" ? "justify-around" : "justify-between"}
            `}
          >

            <TouchableOpacity
              onPress={() => {navigation.navigate("Home")}}
              className={`p-2 rounded-md flex-1 items-center ${screen == "Home" ? " bg-blue-100" : "#9ca3af"}`}
            >
              <Octicons name="home" size={24} color={`${screen == "Home" ? "#007FFF" : "#9ca3af"}`} />
            </TouchableOpacity>
      
            {screen == "messages" && (
              <TouchableOpacity
                onPress={() => {}}
                className="flex-3 items-center px-2"
              >
                <View className="flex-row justify-center bg-black p-2 w-full rounded-full">
                  <Feather name="plus" size={24} color="#fff" />
                  <Text className="pl-2 text-white font-semibold text-base">New chat</Text>
                </View>
              </TouchableOpacity>
            )}
      

            <TouchableOpacity
              onPress={() =>  {navigation.navigate("Map")}}
              className={`p-2 rounded-md flex-1 items-center ${screen == "Map" ? " bg-blue-100" : "#9ca3af"}`}
            >
              <Feather name="map" size={24} color={`${screen == "Map" ? "#007FFF" : "#9ca3af"}`} />
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {navigation.navigate("Messages")}}
              className={`p-2 rounded-md flex-1 items-center ${screen == "messages" ? " hidden" : ""}`}
            >
              <Ionicons name="chatbubble-ellipses-outline" size={24} color="#9ca3af" />
            </TouchableOpacity>

            

            






          </View>
        </View>
      );
      
}
