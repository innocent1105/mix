import React, { useState, useRef, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ImageBackground,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import ChatHeader from "./screens/components/ChatHeader";
import Octicons from '@expo/vector-icons/Octicons';
import Ionicons from '@expo/vector-icons/Ionicons';
import Feather from '@expo/vector-icons/Feather';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import axios from "axios";
import FontAwesome5 from '@expo/vector-icons/FontAwesome5';

import * as ImagePicker from "expo-image-picker";

const loadUserId = async () => {
    try {
      let user_id = await SecureStore.getItemAsync('id');
      if (user_id) {
        console.log("User ID:", user_id);
  
        return user_id;
      } else {
        console.log("No user ID found in storage");
        navigation.replace("Login");
      }
    } catch (error) {
      console.error("Error reading user_id from storage:", error);
    }
};


export default function ChatScreen({ route }){
    const { otherUser } = route.params;
    const [user_id, setUserId] = useState(null)

    let server_api_base_url = "https://www.textiepro.xyz/";

    useEffect(() => {
        const fetchUserId = async () => {
          const id = await loadUserId();
          if (id) {
            console.log("Loaded user ID:", id);
            setUserId(id)
          }
        };
      
        fetchUserId();
    }, []);

    const navigation = useNavigation();
    const STORAGE_KEY = `chat_${user_id}_${otherUser.id}`;

    const[attachmentTab, setAttTab] = useState(false);

    const flatListRef = useRef();
    const [messages, setMessages] = useState([
        // { id: "1", text: "Hey there!", sender: "other", time: "12:44" },
        // { id: "2", text: "Hi! How are you?", sender: "me", time: "12:45", status: "seen" },
        // { id: "3", text: "I’m good bro 🚀", sender: "me", time: "12:46", status: "delivered" },
        // { id: "4", text: "Nice to hear!", sender: "other", time: "12:47" },
    ]);
     

    const loadMessages = async () => {
      try {
        // Load local first
        const storedMessages = await AsyncStorage.getItem(STORAGE_KEY);
        if (storedMessages) {
          setMessages(JSON.parse(storedMessages));
          console.log("Loaded local messages");
          setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
        }
    
        // Then fetch server messages
        const response = await axios.post(`${server_api_base_url}messages.php`, {
          user_id: user_id,
          otherUser: otherUser.id,
        });
    
        if (response.data && response.data.length > 0) {
          setMessages(response.data);
    
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(response.data));
          console.log("Fetched messages from server", response.data);
    
          setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
        } else {
          console.log("Server returned no messages, keeping local");
        }
      } catch (error) {
        console.log("Error loading messages:", error);
      }
    };
    
    
    useEffect(() => {
      if (user_id) {
        loadMessages();
      }
    }, [user_id, otherUser.id]);


    useEffect(() => {
      if (!user_id) return;
    
      const fetchMessages = async () => {
        try {
          const response = await axios.post(`${server_api_base_url}messages.php`, {
            user_id: user_id,
            otherUser: otherUser.id,
          });
    
          if (response.data && response.data.length > 0) {
            setMessages(response.data);
            await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(response.data));
            setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
          }
        } catch (error) {
          console.error("Error fetching messages:", error);
        }
      };
    
      fetchMessages();
      const interval = setInterval(fetchMessages, 2000);
    
      return () => clearInterval(interval);
    }, [user_id, otherUser.id]);
    
 

      

  const [input, setInput] = useState("");

  const scrollRef = useRef(null);

  const sendMessage = async (user_id, otherUser, message) => {

    console.log("user_id : ", user_id)

    if(input.length <= 0){
      // generate ai message with gemini and send to user

    }
    
    const date = new Date().toISOString();
    const key = `chat_${user_id}_${otherUser.id}`;

    setInput("");
  
    try {
      const storedMessages = await AsyncStorage.getItem(key);
      const messages = storedMessages ? JSON.parse(storedMessages) : [];
      const newMessage = {
        id: Date.now().toString(),
        type : "text",
        text: message,
        fromMe: true,
        to: otherUser.id,
        status: "sending",
        date,
      };
      messages.push(newMessage);

      setMessages((prev) => [...prev, newMessage]);

      await AsyncStorage.setItem(key, JSON.stringify(messages));
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);

      const response = await axios.post(
        `${server_api_base_url}send_message.php`,
        {
          user_id,
          otherUser: otherUser.id,
          message,
          date,
        },
        {
          headers: { "Content-Type": "application/json" },
        }
      );
      console.log("res : ", response.data)
  

      if (response.data === "sent") {
        const updatedMessages = messages.map((msg) =>
          msg.id === newMessage.id ? { ...msg, status: "sent" } : msg
        );
        await AsyncStorage.setItem(key, JSON.stringify(updatedMessages));

        return true;
      } else {
        console.error("Failed to send message:", response.data);
        return false;
      }

      
    } catch (err) {
      console.error("Error sending message:", err);
      return false;
    }
  };



  const openAttachmentTab = ()=>{
    if(attachmentTab){
      setAttTab(false);
    }else{
      setAttTab(true);
    }
  }


  const pickImage = async () => {
    // Ask for media library permission
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
  
    if (!permissionResult.granted) {
      alert("Permission to access gallery is required!");
      return;
    }
  
    // Open gallery
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images, // only images
      allowsEditing: true,
      quality: 1,
    });
  
    if (!result.canceled) {
      const selectedImage = result.assets[0].uri;
      console.log("Selected image:", selectedImage);
  
      // You can now send this as a message
      const newMessage = {
        id: Date.now().toString(),
        type : "image",
        image: selectedImage, // <-- save image URI
        fromMe: true,
        to: otherUser.id,
        status: "sending",
        date: new Date().toISOString(),
      };
  
      setMessages((prev) => [...prev, newMessage]);
      // Optionally upload the image to your server
    }
  };
  


  return (
    <View className="flex-1 bg-white">
      <ChatHeader    
        username={otherUser.name} 
        status="online" 
        avatar={otherUser.avatar} 
        onBack={() => navigation.goBack()} 
        
      />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={10}
        className=""
      >

    <ImageBackground
        source={require("../assets/images/chatbg3.jpg")}
      resizeMode="cover"
      className="flex-1"
    >
      <KeyboardAwareScrollView
        ref={scrollRef}
        contentContainerStyle={{ padding: 12, paddingBottom: 5 }}
        extraScrollHeight={20}
        enableOnAndroid={true}
        keyboardShouldPersistTaps="handled"
        onContentSizeChange={() =>
          scrollRef.current?.scrollToEnd({ animated: true })
        }
      >
       {messages.map((item) => (
            <View key={item.id} className="my-1">
                <View
                className={`flex-row ${
                    item.fromMe ? "justify-end" : "justify-start"
                }`}
                >
                <View
                    className={`px-4 py-2 rounded-xl max-w-[70%] ${
                        item.fromMe ? "bg-slate-800" : "bg-gray-200"
                    }`}
                >
                    <Text
                    className={`${
                        item.fromMe ? "text-white" : "text-black"
                    }`}
                    >
                    {item.text}
                    </Text>

                    {item.fromMe && (
                    <View className="flex-row items-center justify-end mt-1">
                        {item.fromMe && (
                            <Text className="text-xs text-gray-500 mt-1 pr-1">
                                {(() => {
                                    const messageDate = new Date(item.date);
                                    const today = new Date();

                                    const isToday =
                                        messageDate.getDate() === today.getDate() &&
                                        messageDate.getMonth() === today.getMonth() &&
                                        messageDate.getFullYear() === today.getFullYear();

                                    return isToday
                                        ? messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
                                        : messageDate.toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); 
                                })()}
                            </Text>
                        )}



                        {item.status === "sending" && (
                            <Feather name="clock" size={16} color="#aaa" />
                        )}

                        {item.status === "sent" && (
                            <Ionicons name="checkmark" size={16} color="#aaa" />
                        )}
                        {item.status === "delivered" && (
                            <Ionicons name="checkmark-done" size={16} color="#aaa" />
                        )}
                        {item.status === "seen" && (
                            <Ionicons name="checkmark-done" size={16} color="#0af" />
                        )}
                    </View>
                    )}

                   
                </View>
                </View>
            </View>
        ))}



      </KeyboardAwareScrollView>
    </ImageBackground>

        {/* <View className="flex-row items-center border-t border-gray-100 p-2 bg-white">
          <TextInput
            className={`
                flex-1 bg-gray-100 border border-gray-200 px-4 py-2 mr-2
                ${
                    input.length >= 50 ? "rounded-xl" : "rounded-full" 
                }
            `}
            placeholder="Type a message..."
            placeholderTextColor="#9ca3af"
            value={input}
            onChangeText={setInput}
            multiline
          />
          <View className =" h-full flex flex-col justify-start">
          {input.length < 1 ? (
            <TouchableOpacity
                onPress={() => sendMessage(user_id, otherUser, input)}
                className="bg-blue-500 px-4 py-2 rounded-full"
            >
               <Ionicons name="sparkles" size={24} color="#fff" />

            </TouchableOpacity>
          ) : (
            <TouchableOpacity
                onPress={() => sendMessage(user_id, otherUser, input)}
                className="bg-blue-500 px-4 py-2 rounded-full"
            >
                <Octicons name="arrow-up" size={24} color="white" />

            </TouchableOpacity>
          )}
           
          </View>
        </View> */}

        <View className=" border-t border-gray-200 p-2 pb-0 bg-white">
         <View className = {`flex-row items-center bg-gray-100 w-full rounded-full p-1 ${
                        input.length >= 50 ? "rounded-xl" : "rounded-full" 
                    }`}>
            <View className =" flex-col p-1 justify-start h-full">
              <TouchableOpacity
                  onPress={() => openAttachmentTab()}
                  className={` ${
                        input.length >= 1 ? " hidden" : "rounded-full" 
                    } bg-blue-500 px-3 py-2`}
              >
                <Feather name="plus" size={20} color="#fff" />

              </TouchableOpacity>

            </View>


            <TextInput
                className={`
                    flex-1 ml-1 bg-gray-100 px-4 py-2 mr-2
               
                `}
                onPress={()=>{setAttTab(false)}}
                placeholder="Type a message..."
                placeholderTextColor="#9ca3af"
                value={input}
                onChangeText={setInput}
                multiline
              />

            <View className =" flex-col justify-start h-full">
              <TouchableOpacity
                  onPress={() => sendMessage(user_id, otherUser, input)}
                  className={`  pr-2 py-2`}
              >
                <FontAwesome6 name="face-grin-wink" size={24} color="#9ca3af" />

              </TouchableOpacity>

            </View>

            {/* Messages crushing after reload or mount. */}



            <View className =" flex-col justify-start h-full">
              <TouchableOpacity
                  onPress={() => sendMessage(user_id, otherUser, input)}
                  className={` mx-2 pr-3 py-2   ${
                        input.length >= 1 ? " hidden" : "rounded-full" 
                    }`}
              >
                <FontAwesome5 name="microphone" size={24} color="#9ca3af" />

              </TouchableOpacity>

            </View>
            
            <View className =" flex-col justify-start h-full">
              <TouchableOpacity
                  onPress={() => sendMessage(user_id, otherUser, input)}
                  className={` ${
                        input.length >= 1 ? " rounded-full" : "hidden" 
                    } bg-blue-500 px-3 py-2`}
              >
                <Feather name="arrow-up" size={20} color="#fff" />

              </TouchableOpacity>

            </View>


         </View>
        {attachmentTab && (
          <View className="p-4">
          <View className="flex-row justify-between">
            <TouchableOpacity
              onPress={pickImage}
              className="bg-white shadow-sm p-5 w-[30%] rounded-2xl items-center"
            >
              <Ionicons name="image-outline" size={24} color="#16a34a" />
              <Text className="mt-2 text-sm font-medium text-gray-700">Gallery</Text>
            </TouchableOpacity>


            <View className="bg-white shadow-sm p-5 w-[30%] rounded-2xl items-center">
              <Feather name="music" size={24} color="#3b82f6" />
              <Text className="mt-2 text-sm font-medium text-gray-700">Audio</Text>
            </View>

            <View className="bg-white shadow-sm p-5 w-[30%] rounded-2xl items-center">
              <FontAwesome6 name="link" size={20} color="#9333ea" />
              <Text className="mt-2 text-sm font-medium text-gray-700">URL</Text>
            </View>
          </View>

          <View className="mt-4 flex-row justify-between">

            <View className="bg-white shadow-sm p-5 w-[30%] rounded-2xl items-center">
              <MaterialIcons name="location-pin" size={24} color="#ef4444" />
              <Text className="mt-2 text-sm font-medium text-gray-700">Location</Text>
            </View>

            <View className="bg-white shadow-sm p-5 w-[30%] rounded-2xl items-center">
              <Feather name="file" size={22} color="#f59e0b" />
              <Text className="mt-2 text-sm font-medium text-gray-700">File</Text>
            </View>

            <View className="bg-white shadow-sm p-5 w-[30%] rounded-2xl items-center">
              <FontAwesome6 name="user" size={20} color="#0ea5e9" />
              <Text className="mt-2 text-sm font-medium text-gray-700">Contact</Text>
            </View>
          </View>
        </View>
        )}

        </View>


      </KeyboardAvoidingView>
      <View className=" p-5"></View>
    </View>
  );
}
