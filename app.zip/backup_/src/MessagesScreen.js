import React, { useState, useRef, useEffect } from "react";
import {
  View,
  Text,
    FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ImageBackground,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import ChatHeader from "./screens/components/ChatHeader";
import Octicons from '@expo/vector-icons/Octicons';
import Ionicons from '@expo/vector-icons/Ionicons';
import Feather from '@expo/vector-icons/Feather';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import axios from "axios";
import ChatList from "./screens/components/MessageUser";
import BottomNav from "./screens/components/BottomNav";
import Stories from "./screens/components/StoriesList";
import * as ImagePicker from "expo-image-picker";

const loadUserId = async () => {
    try {
      let user_id = await SecureStore.getItemAsync('id');
      if (user_id) {
        console.log("User ID:", user_id);
  
        return user_id;
      } else {
        console.log("No user ID found in storage");
        navigation.replace("Login");
      }
    } catch (error) {
      console.error("Error reading user_id from storage:", error);
    }
};

export default function MessagesScreen() {
    const [user_id, setUserId] = useState(null)

    let server_api_base_url = "https://www.textiepro.xyz/";

    useEffect(() => {
        const fetchUserId = async () => {
          const id = await loadUserId();
          if (id) {
            console.log("Loaded user ID:", id);
            setUserId(id);
          }
        };
      
        fetchUserId();
    }, []);

    const navigation = useNavigation();


    const [chats, setChats] = useState([]);
      
    const [loading, setLoading] = useState(true);

 

    const STORAGE_KEY = (userId) => `chats_${userId}`;

    const fetchChats = async () => {
      console.log("Fetching chats...");
      try {
        const localChats = await AsyncStorage.getItem(STORAGE_KEY(user_id));
        if (localChats) {
          setChats(JSON.parse(localChats));
          console.log("Loaded chats from local storage");
        }
    
        const res = await axios.post(`${server_api_base_url}chat_user.php`, {
          user_id: user_id
        });
    
        if (res.data) {
          const transformed = res.data.map((item) => ({
            id: item[0],
            name: item[1],
            avatar: item[2],
            time: item[3],
            lastMessage: item[4],
            messageType: item[5],
            status: item[6],
            isSender: item[7]
          }));
    
          setChats(transformed);
          await AsyncStorage.setItem(STORAGE_KEY(user_id), JSON.stringify(transformed));
          console.log("Chats saved to local");
        }
      } catch (e) {
        console.log("Error fetching chats:", e);
      } finally {
        setLoading(false);
      }
    };
    

  useEffect(() => {
    if (user_id) {  
      fetchChats();
    }
  }, [user_id]);
  

  const dummyStories = [
    { name: "Alice", avatar: "https://i.pravatar.cc/150?img=1" },
    { name: "Bob", avatar: "https://i.pravatar.cc/150?img=2" },
    { name: "Charlie", avatar: "https://i.pravatar.cc/150?img=3" },
    { name: "Charlie", avatar: "https://i.pravatar.cc/150?img=3" },
    { name: "Charlie", avatar: "https://i.pravatar.cc/150?img=3" },
    { name: "Charlie", avatar: "https://i.pravatar.cc/150?img=3" },
    { name: "Charlie", avatar: "https://i.pravatar.cc/150?img=3" },
  ];

  
  return (
    <View className="flex-1 bg-white">
        <View className="absolute top-0 w-full border-b border-gray-200 p-4 pt-14 flex flex-row items-center justify-between bg-white z-10">
            <Text className="font-bold text-2xl">Messages</Text>

            <View className="flex-row space-x-2">
            <TouchableOpacity className="p-2 rounded-md active:bg-gray-100">
                <Feather name="search" size={22} color="black" />
            </TouchableOpacity>

            <TouchableOpacity className="p-2 rounded-md active:bg-gray-100">
                <Octicons name="gear" size={22} color="black" />
            </TouchableOpacity>
            </View>
        </View>


        <View className="mt-4 flex-1">
          <Stories stories={dummyStories} />
          <ChatList chats={chats} navigation={navigation} />
           
        </View>

        <BottomNav screen={"messages"}/>

    </View>

  );
}
