import React from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";


let server_api_base_url = "https://www.textiepro.xyz/";

export default function ChatHeader({ username = "Innocent", status = "online",avatar="", onBack }) {
  const navigation = useNavigation();

  
  return (
    <View className="flex-row items-center bg-white border-b border-gray-200 p-3 pt-12">
      <TouchableOpacity onPress={onBack} className="mr-3">
        <Ionicons name="arrow-back" size={24} color="#333" />
      </TouchableOpacity>

      <View className="flex-row items-center flex-1">
        <View className =" border-2 border-blue-500 rounded-full mr-2">
            <Image
            source={{ uri: `${server_api_base_url}view_pp.php?file=${avatar}` }}
            className="w-10 h-10 rounded-full border"
            />
        </View>

        <View>
          <Text className="text-gray-900 font-semibold text-base">{username}</Text>
          <Text className="text-gray-500 text-xs">{status}</Text>
        </View>
      </View>

      <View className="flex-row space-x-4">
        <TouchableOpacity>
          <Ionicons name="call-outline" size={22} color="#555" />
        </TouchableOpacity>
        <TouchableOpacity>
          <Ionicons name="videocam-outline" size={22} color="#555" />
        </TouchableOpacity>
        <TouchableOpacity>
          <MaterialIcons name="more-vert" size={22} color="#555" />
        </TouchableOpacity>
      </View>
    </View>
  );
}
