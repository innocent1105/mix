import React from "react";
import { View, Text, FlatList, TouchableOpacity, ScrollView, Image } from "react-native";
import Ionicons from '@expo/vector-icons/Ionicons';
import Octicons from '@expo/vector-icons/Octicons';

export default function ChatList({ chats, navigation }) {
  let server_api_base_url = "https://www.textiepro.xyz/";


  const renderItem = ({ item }) => (
    <TouchableOpacity
      className={` 
      ${!item.isSender && item.status != "seen" ? " bg-blue-100 " : " bg-white "}

       flex-row justify-between items-center p-4 border-b border-gray-100`}
      onPress={() => navigation.navigate("Chat", { otherUser: item })}
    >
      <View className="  flex flex-row">
        <Image
            source={{ uri: `${server_api_base_url}view_pp.php?file=${item.avatar}` }}
            className="w-12 h-12 rounded-full mr-4"
        />
        <View className=" h-full">
            <Text className=" text-sm text-gray-800 font-bold">{item.name}</Text>
            <Text className=" text-sm text-gray-500">{item.lastMessage}</Text>
        </View>
      </View>

      <View className=" ">
        <Text className=" text-right text-xs text-gray-400 font-semibold">{item.time}</Text>
        <View className ={`flex-row justify-end ${!item.isSender && " hidden"}`}>
            {item.status == "sent" && (
                <Ionicons name="checkmark-sharp" size={18} color="#aaa" />
            )}
            {item.status == "delivered" && (
                <Ionicons name="checkmark-done-sharp" size={18} color="#aaa" />
            )}
            {item.status == "seen" && (
                <Ionicons name="checkmark-done-sharp" size={18} color="#007FFF" />
            )}
        </View>

    

      </View>

    </TouchableOpacity>
  );

  return (
    <View>
       {chats.length > 0 ? (
          <FlatList 
            data={chats}
            keyExtractor={(item, index) => String(item.id) + "_" + index}
            renderItem={renderItem}
            contentContainerStyle={{ paddingBottom: 190 }}
          />
        ) : (
          <View className="p-10 items-center">
            <Ionicons name="chatbubble-ellipses-outline" size={40} color="#9ca3af" />
            <Text className="text-gray-500 mt-2">No chats yet</Text>
            <Text className="text-gray-400 text-center px-5 text-xs mt-2">You do not have any chats at the moment. Press New chat to start chatting with friends.</Text>
          </View>
        )}

 
    </View>
    
  );
}
