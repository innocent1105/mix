import React from "react";
import { View, Text, ScrollView, Image, TouchableOpacity } from "react-native";
import AntDesign from '@expo/vector-icons/AntDesign';

export default function Stories({ stories }) {
  return (
    <View className=" border-b border-gray-200 p-2 mt-24 bg-white">
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <TouchableOpacity
            key={1}
            className="items-center mr-4"
            onPress={() => console.log("Story clicked:")}
          >
            <View className="w-16 h-16 flex-col justify-center bg-gray-200 rounded-full border-2 border-gray-300 p-1">
                <View className =" flex-row justify-center">
                    <AntDesign name="plus" size={24} color="#aaa" />
                </View>
            </View>
            <Text className="text-xs font-semibold text-gray-700 text-center mt-1">Upload</Text>
          </TouchableOpacity>

        {stories.map((story, index) => (
          <TouchableOpacity
            key={index}
            className="items-center mr-4"
            onPress={() => console.log("Story clicked:", story.name)}
          >
            <View className="w-16 h-16 rounded-full border-2 border-blue-400 p-1">
              <Image
                source={{ uri: story.avatar }}
                className="w-full h-full rounded-full"
              />
            </View>
            <Text className="text-xs font-semibold text-gray-700 text-center mt-1">{story.name}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}
