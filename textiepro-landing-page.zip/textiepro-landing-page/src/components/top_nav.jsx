import React, { useState } from 'react';
import '../App.css';
import '../tailwind.css';
import { Heart, Menu, X } from 'lucide-react';
import { Link } from "react-router-dom";

const TopNav = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);

  // Helper for closing menu when a link is clicked
  const closeMenu = () => setIsOpen(false);

  return (
    <nav className="nav-blur" style={{ zIndex: 1000 }}>
      <div className="nav-content">
        {/* Logo */}
        <Link to="/" onClick={closeMenu} style={{ textDecoration: 'none' }}>
          <div className="clickable-bounce" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '32px', height: '32px', background: 'var(--hot-pink)', borderRadius: '10px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <Heart size={18} fill="white" color="white" />
            </div>
            <span style={{ fontWeight: 900, fontSize: '1.25rem', letterSpacing: '-1px', color: 'white' }}>Textie</span>
          </div>
        </Link>

        {/* Desktop Links */}
        <div className="nav-links" style={{ display: 'none', gap: '2rem', fontWeight: 600, fontSize: '0.9rem', color: '#ccc' }}>
          <Link to="/safety" style={{ textDecoration: 'none', color: 'inherit' }}>Safety</Link>
          <Link to="/success_stories" style={{ textDecoration: 'none', color: 'inherit' }}>Success Stories</Link>
          <Link to="/guidelines" style={{ textDecoration: 'none', color: 'inherit' }}>Community Guidelines</Link>
          <Link to="/terms" style={{ textDecoration: 'none', color: 'inherit' }}>Terms</Link>
          <Link to="/contact" style={{ textDecoration: 'none', color: 'inherit' }}>Contact</Link>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <button className="cta-pill clickable-bounce" style={{ display: 'none' }}>Download App</button>
          
          {/* Mobile Toggle Button */}
          <button 
            className="mobile-menu-toggle" 
            onClick={toggleMenu}
            style={{ background: 'none', border: 'none', color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
          >
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      <div className={`mobile-dropdown ${isOpen ? 'open' : ''}`}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', padding: '2rem' }}>
          <Link to="/terms" onClick={closeMenu} className="mobile-link">Terms of Usage</Link>
          <Link to="/safety" onClick={closeMenu} className="mobile-link">Safety</Link>
          <Link to="/success_stories" onClick={closeMenu} className="mobile-link">Success Stories</Link>
          <Link to="/contact" onClick={closeMenu} className="mobile-link">Contact</Link>
          <Link to="/guidelines" onClick={closeMenu} className="mobile-link">Community Guidelines</Link>
          <hr style={{ border: 'none', borderTop: '1px solid #222', margin: '0.5rem 0' }} />
          <button className="cta-pill clickable-bounce" style={{ width: '100%' }}>Download App</button>
        </div>
      </div>

      <style>{`
        /* Desktop Logic */
        @media (min-width: 900px) {
          .nav-links { display: flex !important; }
          .cta-pill { display: block !important; }
          .mobile-menu-toggle { display: none !important; }
          .mobile-dropdown { display: none !important; }
        }

        /* Mobile Dropdown Styles */
        .mobile-dropdown {
          position: fixed;
          top: 70px; /* Adjust based on your nav height */
          left: 0;
          right: 0;
          background: rgba(13, 13, 14, 0.98);
          backdrop-filter: blur(20px);
          border-bottom: 1px solid var(--glass-border);
          overflow: hidden;
          max-height: 0;
          transition: max-height 0.4s ease-in-out, opacity 0.3s;
          opacity: 0;
          z-index: 999;
        }

        .mobile-dropdown.open {
          max-height: 500px;
          opacity: 1;
        }

        .mobile-link {
          text-decoration: none;
          color: white;
          font-size: 1.2rem;
          font-weight: 700;
          transition: color 0.2s;
        }

        .mobile-link:active {
          color: var(--hot-pink);
        }
      `}</style>
    </nav>
  );
};

export default TopNav;