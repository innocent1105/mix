import React, { useEffect } from 'react';
import '../App.css';
import '../tailwind.css';
import { 
  Heart, Shield, Zap, Star, Apple, PlayCircle, 
  Instagram, Twitter, Github, Mail, MapPin, Search, Menu
} from 'lucide-react';
import { Link } from "react-router-dom";

const Footer = () => {
  return (
      <footer className="big-footer">
        <div className="footer-grid">
          <div className="footer-col">
            <div className="clickable-bounce" style={{display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.5rem'}}>
               <div style={{width: '30px', height: '30px', background: 'var(--hot-pink)', borderRadius: '8px'}}></div>
               <span style={{fontWeight: 900, fontSize: '1.5rem', color: 'white'}}>Textie</span>
            </div>
            <p style={{color: '#666', lineHeight: 1.6, fontSize: '0.9rem'}}>
              Building the world's most intentional dating community. quality over quantity.
            </p>
            <div style={{display: 'flex', gap: '1.5rem', marginTop: '2rem'}}>
               <Instagram size={20} className="clickable-bounce" color="#444" />
               <Twitter size={20} className="clickable-bounce" color="#444" />
               <Github size={20} className="clickable-bounce" color="#444" />
            </div>
          </div>

          <div className="footer-col">
            <h4 style={{color: 'var(--hot-pink)', marginBottom: '1.2rem', fontSize: '0.8rem', letterSpacing: '1px'}}>PLATFORM FEATURES</h4>
            <ul style={{listStyle: 'none', padding: 0}}>
              {['Match users', 'Like and Swipe profile', 'Verification', 'Map-based Posts and Events'].map(item => (
                <li key={item} style={{marginBottom: '0.8rem'}}><a href="#" className="clickable-bounce" style={{color: '#666', textDecoration: 'none', fontSize: '0.9rem'}}>{item}</a></li>
              ))}
            </ul>
          </div>

          <div className="footer-col">
            <h4 style={{color: 'var(--hot-pink)', marginBottom: '1.2rem', fontSize: '0.8rem', letterSpacing: '1px'}}>SUPPORT</h4>
            <ul style={{listStyle: 'none', padding: 0}}>
              {['Safety', 'Privacy', 'Terms', 'Contact'].map(item => (
                <li key={item} style={{ marginBottom: '0.8rem' }}>
                    <Link
                        to={`/${item.toLowerCase().replace(/\s+/g, '-')}`}
                        className="clickable-bounce"
                        style={{ color: '#666', textDecoration: 'none', fontSize: '0.9rem' }}
                    >
                        {item}
                    </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="footer-col">
            <h4 style={{color: 'var(--hot-pink)', marginBottom: '1.2rem', fontSize: '0.8rem', letterSpacing: '1px'}}>NEWSLETTER</h4>
            <div style={{position: 'relative', maxWidth: '300px'}}>
              <input type="text" placeholder="Email" style={{width: '100%', background: '#111', border: '1px solid #222', padding: '0.8rem 1rem', borderRadius: '10px', color: 'white'}} />
              <button className="clickable-bounce" style={{position: 'absolute', right: '5px', top: '5px', background: 'var(--maroon)', border: 'none', color: 'white', padding: '0.4rem 1rem', borderRadius: '6px'}}>
                <Zap size={14} />
              </button>
            </div>
          </div>
        </div>

        <div className="footer-bottom" style={{maxWidth: '1200px', margin: '4rem auto 0', borderTop: '1px solid #1a1a1c', paddingTop: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem', color: '#444', fontSize: '0.75rem'}}>
          <span>© 2026 Cynite Technologies.inc</span>
          <div style={{display: 'flex', gap: '1.5rem', flexWrap: 'wrap'}}>
             <span className="clickable-bounce" style={{display: 'flex', alignItems: 'center', gap: '5px'}}><MapPin size={12}/>Lusaka, Zambia.</span>
             <span className="clickable-bounce" style={{display: 'flex', alignItems: 'center', gap: '5px'}}><Mail size={12}/> textie@gmail.com</span>
          </div>
        </div>

        <style>{`
          @media (min-width: 768px) {
            .footer-bottom { flex-direction: row; justify-content: space-between; margin-top: 6rem; }
          }
        `}</style>
      </footer>
  );
};

export default Footer;