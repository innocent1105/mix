import React, { useEffect } from 'react';
import '../App.css';
import { Heart, Star, Quote, MessageCircle, MapPin } from 'lucide-react';
import TopNav from '../components/top_nav';
import Footer from '../components/footer';

// Importing your assets for the story cards
import model1 from '../assets/model1.jpg';
import model2 from '../assets/model2.jpg';
import model3 from '../assets/model3.jpg';
import model5 from '../assets/model5.jpg';

const TextieSuccess = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('active'); });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  }, []);

  const stories = [
    {
      pair: "Sarah & David",
      location: "Lusaka, Zambia",
      image: model1,
      story: "We matched through a 'Jazz Night' event on the Map. We've been inseparable for 6 months now. Textie's intent-based matching is a game changer.",
      daysToMatch: "3 Days"
    },
    {
      pair: "Marcus & Elena",
      location: "Cape Town, SA",
      image: model2,
      story: "The VibeCheck AI actually works. I felt safe meeting Marcus because I knew he was verified. Best decision I ever made.",
      daysToMatch: "1 Week"
    },
    {
      pair: "Tionge & Kondwani",
      location: "Ndola, Zambia",
      image: model3,
      story: "No shallow swipes. We talked about psychology and travel for three hours before even meeting. Our vibes just aligned perfectly.",
      daysToMatch: "2 Days"
    }
  ];

  return (
    <div className="app-container">
      <TopNav />

      {/* --- HERO SECTION --- */}
      <section style={{ paddingTop: '10rem', paddingBottom: '5rem' }} className="reveal">
        <center>
          <div className="clickable-bounce" style={{border: '1px solid var(--maroon)', width: 'fit-content', padding: '0.5rem 1.2rem', borderRadius: '50px', marginBottom: '1.5rem', background: 'rgba(128, 18, 62, 0.1)'}}>
            <span style={{color: 'var(--hot-pink)', fontSize: '0.7rem', fontWeight: 700}}>💞 REAL VIBES, REAL PEOPLE</span>
          </div>
          <h1 className="hero-text" style={{ fontWeight: 900, color: 'white', margin: 0 }}>
            Matches made in <br />
            <span style={{ color: 'var(--hot-pink)' }}>the right language.</span>
          </h1>
          <p className="hero-subtext" style={{ color: '#888', marginTop: '1.5rem' }}>
            Thousands of intentional connections happen on Textie every day. Here are a few of our favorite journeys.
          </p>
        </center>
      </section>

      {/* --- FEATURED STORY --- */}
      <section style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 1.5rem 5rem' }} className="reveal">
        <div style={{ 
          background: 'linear-gradient(135deg, #111 0%, #050505 100%)', 
          borderRadius: '40px', 
          border: '1px solid var(--glass-border)', 
          display: 'flex', 
          flexDirection: 'row', 
          flexWrap: 'wrap',
          overflow: 'hidden',
          boxShadow: '0 40px 100px rgba(0,0,0,0.5)'
        }}>
          <div style={{ flex: '1', minWidth: '300px', height: '500px', backgroundImage: `url(${model5})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
          <div style={{ flex: '1.2', padding: '4rem 3rem', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <Quote size={40} color="var(--hot-pink)" style={{ marginBottom: '1rem', opacity: 0.5 }} />
            <h2 style={{ color: 'white', fontSize: '2.5rem', fontWeight: 900, lineHeight: 1.1, marginBottom: '1.5rem' }}>
              "We didn't just find a match; we found a soulmate."
            </h2>
            <p style={{ color: '#888', fontSize: '1.1rem', marginBottom: '2rem', fontStyle: 'italic' }}>
              "The Map feature allowed us to meet at a local art gallery event. It wasn't awkward because we already knew we shared the same intent."
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
              <div style={{ width: '50px', height: '50px', borderRadius: '50%', background: 'var(--hot-pink)', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <Heart fill="white" color="white" size={20} />
              </div>
              <div>
                <h4 style={{ color: 'white', margin: 0 }}>Chanda & Maya</h4>
                <span style={{ color: '#555', fontSize: '0.8rem' }}>Matched in Lusaka</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- STORY GRID --- */}
      <section style={{ maxWidth: '1200px', margin: '0 auto', padding: '5rem 1.5rem 10rem' }} className="reveal">
        <div className="success-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2.5rem' }}>
          {stories.map((s, i) => (
            <div key={i} className="clickable-bounce" style={{ background: '#0d0d0e', borderRadius: '30px', border: '1px solid var(--glass-border)', overflow: 'hidden' }}>
              <div style={{ height: '300px', backgroundImage: `url(${s.image})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
              <div style={{ padding: '2rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                  <span style={{ color: 'var(--hot-pink)', fontSize: '0.75rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px' }}>Match Time: {s.daysToMatch}</span>
                  <div style={{ display: 'flex', gap: '2px' }}>{[1,2,3,4,5].map(n => <Star key={n} size={12} fill="var(--hot-pink)" color="var(--hot-pink)" />)}</div>
                </div>
                <h3 style={{ color: 'white', margin: '0 0 10px 0', fontSize: '1.5rem' }}>{s.pair}</h3>
                <p style={{ color: '#666', fontSize: '0.95rem', lineHeight: 1.6, marginBottom: '1.5rem' }}>"{s.story}"</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#444', fontSize: '0.8rem' }}>
                  <MapPin size={14} /> {s.location}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --- CTA SECTION --- */}
      <section className="reveal" style={{ paddingBottom: '10rem' }}>
        <center>
          <div style={{ background: 'var(--glass)', border: '1px solid var(--glass-border)', padding: '4rem 2rem', borderRadius: '40px', maxWidth: '800px' }}>
            <MessageCircle size={40} color="var(--hot-pink)" style={{ marginBottom: '1.5rem' }} />
            <h2 style={{ color: 'white', marginBottom: '1rem' }}>Ready for your own story?</h2>
            <p style={{ color: '#666', marginBottom: '2.5rem' }}>Join 50,000+ others finding intentional connections.</p>
            <button className="cta-pill clickable-bounce" style={{ padding: '1rem 3rem', fontSize: '1.1rem' }}>
              Download Textie
            </button>
          </div>
        </center>
      </section>

      <Footer />
    </div>
  );
};

export default TextieSuccess;