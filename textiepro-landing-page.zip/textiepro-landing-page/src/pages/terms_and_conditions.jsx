import React, { useEffect } from 'react';
import '../App.css';
import { Heart, ArrowLeft, ShieldCheck, Scale, Lock, FileText, ChevronRight } from 'lucide-react';
import TopNav from '../components/top_nav';
import Footer from '../components/footer';

const TextieTerms = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('active'); });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  }, []);

  const sections = [
    { id: "rules", title: "1. Textie Rules" },
    { id: "content", title: "2. Types of Content" },
    { id: "restrictions", title: "3. Restrictions" },
    { id: "safety", title: "4. Safety Policy" },
    { id: "payment", title: "5. Payment Terms" }
  ];

  return (
    <div className="app-container" style={{ color: '#ccc', lineHeight: '1.8' }}>
      <TopNav />

      {/* --- HEADER --- */}
      <header style={{ paddingTop: '10rem', paddingBottom: '4rem', background: 'linear-gradient(to bottom, #1a050d 0%, var(--bg-dark) 100%)' }}>
        <center className="reveal">
          <h1 className="hero-text" style={{ fontWeight: 900, color: 'white', marginBottom: '1rem' }}>
            Terms of <span style={{color: 'var(--hot-pink)'}}>Service</span>
          </h1>
          <p style={{ maxWidth: '600px', opacity: 0.7 }}>Last updated: February 13, 2026. Please read these terms carefully.</p>
        </center>
      </header>

      <main style={{ maxWidth: '1000px', margin: '0 auto', padding: '0 1.5rem 10rem', display: 'grid', gridTemplateColumns: '1fr', gap: '4rem' }}>
        
        {/* --- TABLE OF CONTENTS (Desktop Sticky) --- */}
        <div className="reveal sticky-toc" style={{ background: '#111', padding: '2rem', borderRadius: '25px', border: '1px solid var(--glass-border)', height: 'fit-content' }}>
          <h4 style={{ color: 'white', marginBottom: '1.5rem', fontSize: '0.9rem', letterSpacing: '1px' }}>CONTENTS</h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {sections.map(s => (
              <a key={s.id} href={`#${s.id}`} style={{ color: '#888', textDecoration: 'none', fontSize: '0.9rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }} className="toc-link">
                {s.title} <ChevronRight size={14} color="var(--hot-pink)" />
              </a>
            ))}
          </div>
        </div>

        {/* --- LEGAL TEXT --- */}
        <div className="reveal legal-body" style={{ color: '#aaa', fontSize: '0.95rem' }}>
          
          <section id="rules" style={{ marginBottom: '4rem' }}>
            <h2 style={{ color: 'white', marginBottom: '1.5rem' }}>1. TEXTIE RULES</h2>
            <p>Before you can use the App, you will need to register for an account (“Account”). In order to create an Account you must be at least 18 years old and legally permitted to use the App by the laws of your home country.</p>
            <p style={{ marginTop: '1rem' }}>You can create an Account via manual registration, or by using your social login details. By using Textie, you acknowledge that we may collect and use your data in accordance with our <strong>Privacy Policy</strong>.</p>
            <p style={{ marginTop: '1rem' }}>Cynite Technologies uses a combination of automated systems, user reports, and a team of moderators to review accounts and content to identify breaches of these Terms. We reserve the right at our sole discretion to terminate or suspend any Account.</p>
          </section>

          <section id="content" style={{ marginBottom: '4rem' }}>
            <h2 style={{ color: 'white', marginBottom: '1.5rem' }}>2. TYPES OF CONTENT</h2>
            <p>There are three types of content on the App: <strong>Your Content</strong> (uploaded by you), <strong>Member Content</strong> (provided by other users), and <strong>Our Content</strong> (owned by Cynite Technologies).</p>
            <h4 style={{ color: 'var(--hot-pink)', marginTop: '2rem' }}>Prohibited Content</h4>
            <ul style={{ paddingLeft: '1.5rem', marginTop: '1rem' }}>
              <li>Illegal activity promotion or harm to minors.</li>
              <li>Defamatory, obscene, or pornographic material.</li>
              <li>Discriminatory language promoting racism, sexism, or bigotry.</li>
              <li>Spyware, viruses, or malicious code.</li>
            </ul>
          </section>

          <section id="restrictions" style={{ marginBottom: '4rem' }}>
            <h2 style={{ color: 'white', marginBottom: '1.5rem' }}>3. RESTRICTIONS ON THE APP</h2>
            <p>You agree to use your real name and real age. You will not stalk, harass, or use the App in any deceptive or manipulative way. Scraping or replicating any part of the App without our prior consent is expressly prohibited.</p>
            <div style={{ padding: '1.5rem', background: '#1a050d', borderLeft: '4px solid var(--hot-pink)', marginTop: '2rem', borderRadius: '0 15px 15px 0' }}>
              <p style={{ fontSize: '0.85rem', color: '#eee' }}><strong>CRIMINAL BACKGROUND CHECKS:</strong> Cynite Technologies may investigate whether a member has a criminal history in response to suspected misconduct. We reserve the right to block members for violent offenses or violations of these terms.</p>
            </div>
          </section>

          <section id="safety" style={{ marginBottom: '4rem' }}>
            <h2 style={{ color: 'white', marginBottom: '1.5rem' }}>4. SAFETY POLICY</h2>
            <p>Consent is required at all times. Everyone on Textie is expected to discuss and respect boundaries. If you experience relationship abuse, we partner with specialized trauma support services to provide online assistance.</p>
            <p style={{ marginTop: '1rem' }}>We use human moderators and automated systems to monitor interactions for content that may be harmful or against our community guidelines.</p>
          </section>

          <section id="payment">
            <h2 style={{ color: 'white', marginBottom: '1.5rem' }}>5. PAYMENT TERMS</h2>
            <p>Textie may offer products for In-App Purchase. Subscriptions automatically renew at the end of the period unless you cancel via your App Store or Google Play settings. Deleting your account does not automatically cancel a third-party subscription.</p>
          </section>

        </div>
      </main>

      <Footer />

      <style>{`
        .legal-body p { margin-bottom: 1.2rem; }
        .legal-body section { scroll-margin-top: 100px; }
        .toc-link:hover { color: white !important; transform: translateX(5px); transition: all 0.3s; }
        
        @media (min-width: 900px) {
          main { grid-template-columns: 280px 1fr; }
          .sticky-toc { position: sticky; top: 120px; }
        }
      `}</style>
    </div>
  );
};

export default TextieTerms;