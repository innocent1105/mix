import React, { useEffect } from 'react';
import '../App.css';
import '../tailwind.css';
import { 
  Heart, Shield, Zap, Star, Apple, PlayCircle, 
  Instagram, Twitter, Github, Mail, MapPin, Search, Menu
} from 'lucide-react';
import screen1 from '../assets/model1.jpg'; 
import screen2 from '../assets/model2.jpg'; 
import screen3 from '../assets/model3.jpg'; 
import screen4 from '../assets/model4.jpg'; 
import screen5 from '../assets/model5.jpg'; 
import TopNav from '../components/top_nav';
import Footer from '../components/footer';
const TextieFinal = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('active'); });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  }, []);

  const galleryImages = [
    screen5,
    screen3,
    screen2,
    screen1,
    screen4,
  ];

  return (
    <div className="app-container">
      <TopNav />    


      {/* --- HERO SECTION --- */}
      <section style={{padding: '10rem 1.5rem 0'}} className="reveal">
        <center>
          <div className="clickable-bounce" style={{border: '1px solid var(--maroon)', width: 'fit-content', padding: '0.5rem 1.2rem', borderRadius: '50px', marginBottom: '1.5rem', background: 'rgba(128, 18, 62, 0.1)'}}>
            <span style={{color: 'var(--hot-pink)', fontSize: '0.7rem', fontWeight: 700}}>✨ NEW: FIND LOVE ON THE MAP.</span>
          </div>
          
          <h1 className="hero-text" style={{fontWeight: 900, margin: 0, lineHeight: 1, color: 'white'}}>
            Meet the one who <br />
            <span style={{color: 'var(--hot-pink)'}}>speaks your language.</span>
          </h1>
          <p className="hero-subtext" style={{color: '#888', marginTop: '1.5rem', lineHeight: 1.5}}>
            Built for people who are done with shallow swiping. 
            Textie matches you with individuals who share your intent — so every conversation has real potential.
          </p>


          {/* Responsive Buttons */}
          <div className="hero-btns" style={{marginTop: '3rem', display: 'flex', gap: '12px', justifyContent: 'center', flexWrap: 'wrap'}}>
             <div className="clickable-bounce" style={{display: 'flex', alignItems: 'center', gap: '10px', background: '#111', padding: '0.8rem 1.5rem', borderRadius: '15px', border: '1px solid var(--glass-border)', color: 'white', minWidth: '160px'}}>
                <Apple size={24} /> <div style={{textAlign: 'left'}}><small style={{display: 'block', fontSize: '0.6rem'}}>Download on</small>App Store</div>
             </div>
             <div className="clickable-bounce" style={{display: 'flex', alignItems: 'center', gap: '10px', background: '#111', padding: '0.8rem 1.5rem', borderRadius: '15px', border: '1px solid var(--glass-border)', color: 'white', minWidth: '160px'}}>
                <PlayCircle size={24} /> <div style={{textAlign: 'left'}}><small style={{display: 'block', fontSize: '0.6rem'}}>Get it on</small>Google Play</div>
             </div>
          </div>
        </center>

        <style>{`
          .hero-text { font-size: 2.8rem; }
          .hero-subtext { font-size: 1.1rem; max-width: 100%; }
          @media (min-width: 768px) {
            .hero-text { font-size: 5.5rem; }
            .hero-subtext { font-size: 1.4rem; max-width: 700px; }
            .hero-btns { gap: 20px; }
          }
        `}</style>
      </section>

      <section style={{padding: '5rem 0', overflow: 'hidden'}} className="reveal">
        <div className="gallery-scroll" style={{display: 'flex', gap: '20px', padding: '0 1.5rem'}}>
          {galleryImages.map((imgUrl, i) => (
            <div key={i} className="clickable-bounce" style={{
              minWidth: '240px', 
              height: '480px', 
              borderRadius: '35px', 
              border: '6px solid #1a1a1c', 
              boxShadow: '0 30px 60px rgba(0,0,0,0.5)', 
              overflow: 'hidden', 
              position: 'relative', 
              flexShrink: 0,
              backgroundImage: `url(${imgUrl})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}>
              <div style={{
                padding: '1.5rem', 
                height: '100%', 
                display: 'flex', 
                flexDirection: 'column', 
                justifyContent: 'flex-end',
                background: 'linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 40%)'
              }}>
                <div style={{width: '35px', height: '35px', borderRadius: '50%', background: 'var(--hot-pink)', marginBottom: '1rem', border: '2px solid white'}}></div>
                <div style={{height: '10px', width: '80%', background: 'white', borderRadius: '10px', marginBottom: '8px', opacity: 0.8}}></div>
              </div>
            </div>
          ))}
        </div>
         <style>{`
          .gallery-scroll { 
            overflow-x: auto; 
            scrollbar-width: none; 
            -ms-overflow-style: none;
            cursor: grab;
          }
          .gallery-scroll::-webkit-scrollbar { display: none; }
          
          @media (min-width: 1024px) {
            .gallery-scroll { 
              justify-content: center; 
              transform: rotate(-2deg); 
              overflow: visible;
            }
            .gallery-scroll > div { min-width: 280px; height: 560px; }
          }
        `}</style>
      </section>

    <Footer />
    </div>
  );
};

export default TextieFinal;