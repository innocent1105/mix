import React, { useEffect } from 'react';
import '../App.css';
import { Mail, MapPin, Send, MessageCircle, Globe } from 'lucide-react';
import TopNav from '../components/top_nav';
import Footer from '../components/footer';

const TextieContact = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('active'); });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  }, []);

  return (
    <div className="app-container">
      <TopNav />

      <section style={{ paddingTop: '10rem', paddingBottom: '3rem' }} className="reveal">
        <center>
          <div className="clickable-bounce" style={{border: '1px solid var(--maroon)', width: 'fit-content', padding: '0.5rem 1.2rem', borderRadius: '50px', marginBottom: '1.5rem', background: 'rgba(128, 18, 62, 0.1)'}}>
            <span style={{color: 'var(--hot-pink)', fontSize: '0.7rem', fontWeight: 700}}>👋 WE'RE ALL EARS</span>
          </div>
          <h1 className="hero-text" style={{ fontWeight: 900, color: 'white', margin: 0 }}>
            Let's start a <span style={{ color: 'var(--hot-pink)' }}>conversation.</span>
          </h1>
          <p className="hero-subtext" style={{ color: '#888', marginTop: '1rem' }}>
            Have questions about Textie. App or just want to say hi? Our team typically responds within 2 hours.
          </p>
        </center>
      </section>

      <section style={{ maxWidth: '1100px', margin: '0 auto', padding: '2rem 1.5rem 10rem' }} className="reveal">
        <div className="contact-grid">
          
          <div className="info-side" style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div className="clickable-bounce glass-card" style={{ padding: '2rem', borderRadius: '25px', background: 'var(--glass)', border: '1px solid var(--glass-border)' }}>
              <div style={{ display: 'flex', gap: '15px', alignItems: 'flex-start' }}>
                <div style={{ padding: '12px', background: 'rgba(255, 79, 149, 0.1)', borderRadius: '12px' }}>
                  <Mail color="var(--hot-pink)" />
                </div>
                <div>
                  <h4 style={{ color: 'white', margin: '0 0 5px 0' }}>Email Us</h4>
                  <p style={{ color: '#666', fontSize: '0.9rem', margin: 0 }}>textie@gmail.com</p>
                </div>
              </div>
            </div>

            <div className="clickable-bounce glass-card" style={{ padding: '2rem', borderRadius: '25px', background: 'var(--glass)', border: '1px solid var(--glass-border)' }}>
              <div style={{ display: 'flex', gap: '15px', alignItems: 'flex-start' }}>
                <div style={{ padding: '12px', background: 'rgba(255, 79, 149, 0.1)', borderRadius: '12px' }}>
                  <MapPin color="var(--hot-pink)" />
                </div>
                <div>
                  <h4 style={{ color: 'white', margin: '0 0 5px 0' }}>Headquarters</h4>
                  <p style={{ color: '#666', fontSize: '0.9rem', margin: 0 }}>Lusaka, Zambia</p>
                </div>
              </div>
            </div>

            <div className="clickable-bounce glass-card" style={{ padding: '2rem', borderRadius: '25px', background: 'var(--glass)', border: '1px solid var(--glass-border)' }}>
              <div style={{ display: 'flex', gap: '15px', alignItems: 'flex-start' }}>
                <div style={{ padding: '12px', background: 'rgba(255, 79, 149, 0.1)', borderRadius: '12px' }}>
                  <MessageCircle color="var(--hot-pink)" />
                </div>
                <div>
                  <h4 style={{ color: 'white', margin: '0 0 5px 0' }}>Live Support</h4>
                  <p style={{ color: '#666', fontSize: '0.9rem', margin: 0 }}>Available in-app 24/7</p>
                </div>
              </div>
            </div>
          </div>

          <div className="form-side" style={{ background: '#111', padding: '2.5rem', borderRadius: '30px', border: '1px solid var(--glass-border)' }}>
            <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <div style={{ flex: 1, minWidth: '200px' }}>
                  <label style={{ color: '#555', fontSize: '0.75rem', fontWeight: 700, marginBottom: '8px', display: 'block' }}>FULL NAME</label>
                  <input type="text" placeholder="John Doe" className="contact-input" />
                </div>
                <div style={{ flex: 1, minWidth: '200px' }}>
                  <label style={{ color: '#555', fontSize: '0.75rem', fontWeight: 700, marginBottom: '8px', display: 'block' }}>EMAIL ADDRESS</label>
                  <input type="email" placeholder="john@example.com" className="contact-input" />
                </div>
              </div>
              
              <div>
                <label style={{ color: '#555', fontSize: '0.75rem', fontWeight: 700, marginBottom: '8px', display: 'block' }}>SUBJECT</label>
                <select className="contact-input" style={{ appearance: 'none' }}>
                  <option>General Inquiry</option>
                  <option>Account Support</option>
                  <option>Partnership</option>
                  <option>Feedback</option>
                </select>
              </div>

              <div>
                <label style={{ color: '#555', fontSize: '0.75rem', fontWeight: 700, marginBottom: '8px', display: 'block' }}>YOUR MESSAGE</label>
                <textarea placeholder="Tell us what's on your mind..." className="contact-input" style={{ height: '120px', resize: 'none' }}></textarea>
              </div>

              <button className="cta-pill clickable-bounce" style={{ width: '100%', padding: '1rem', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px' }}>
                <Send size={18} /> Send Message
              </button>
            </form>
          </div>

        </div>

        <style>{`
          .contact-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 3rem;
          }
          .contact-input {
            width: 100%;
            background: #0d0d0e;
            border: 1px solid #222;
            border-radius: 12px;
            padding: 1rem;
            color: white;
            font-size: 0.9rem;
            transition: border 0.3s;
          }
          .contact-input:focus {
            outline: none;
            border-color: var(--hot-pink);
          }
          @media (min-width: 900px) {
            .contact-grid { grid-template-columns: 1fr 1.5fr; }
          }
        `}</style>
      </section>

      <Footer />
    </div>
  );
};

export default TextieContact;