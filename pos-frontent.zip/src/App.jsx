import React, { useState, useEffect } from 'react';
import { 
  Search, Package, Users, LayoutDashboard, Settings, 
  Bell, X, Plus, Trash2, MapPin, Navigation, Maximize2, Minimize2 
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Custom Marker to match UI
const customIcon = new L.Icon({
  iconUrl: 'https://www.freeiconspng.com/images/pin-png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const createCustomIcon = (orderImg, status) => {
  const ringColor = 
    status === 'Completed' ? '#10b981' : 
    status === 'Pending' ? '#6366f1' :   
    '#ef4444';                           

  return L.divIcon({
    className: 'custom-marker',
    html: `
    <center>
      <div style="position: relative; width: 88px; height: 88px;">
        <div style="
          position: absolute;
          inset: 0;
          background: ${ringColor};
          border-radius: 50%;
          opacity: 0.2;
          animation: pulse 2s infinite;
        "></div>
        
        <div style="
          position: absolute;
          inset: 4px;
          background: white;
          border-radius: 50%;
          border: 3px solid ${ringColor};
          overflow: hidden;
          box-shadow: 0 4px 15px rgba(0,0,0,0.25);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 20;
        ">
          <img src="${orderImg}" style="width: 100%; height: auto; object-cover: cover;" />
        </div>

        <div style="
          position: absolute;
          bottom: -6px;
          left: 50%;
          transform: translateX(-50%);
          width: 0; 
          height: 0; 
          border-left: 8px solid transparent;
          border-right: 8px solid transparent;
          border-top: 10px solid ${ringColor};
          z-index: 10;
        "></div>
      </div>
    </center>
    `,
    iconSize: [48, 48],
    iconAnchor: [24, 48], // Anchors the "tip" of the triangle to the coordinate
    popupAnchor: [0, -50]
  });
};

const OrderTrackingAdmin = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false);
  const [isMapMaximized, setIsMapMaximized] = useState(false);
  const currency = "ZMW";

  const [orders, setOrders] = useState([
    { id: 'ORD-7721', name: 'Ultra-Wide Monitor', customer: 'James Chalwe', date: '2026-02-01', total: 8500.00, status: 'Completed', img: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=150', lat: -15.3875, lng: 28.3228 },
    { id: 'ORD-8820', name: 'Ergonomic Chair', customer: 'Moses L Milambo', date: '2026-02-02', total: 3200.50, status: 'Pending', img: 'https://images.unsplash.com/photo-1505797149-35ebcb05a6fd?w=150', lat: -15.4167, lng: 28.2833 },
    { id: 'ORD-9901', name: 'Mechanical Keyboard', customer: 'Robert Chiluba', date: '2026-01-28', total: 1250.00, status: 'Canceled', img: 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=150', lat: -15.4000, lng: 28.3000 },
  ]);

  const handleAddOrder = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newOrder = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      name: formData.get('product'),
      customer: formData.get('customer'),
      date: new Date().toISOString().split('T')[0],
      total: parseFloat(formData.get('amount')),
      status: 'Pending',
      lat: -15.3875 + (Math.random() * 0.05), 
      lng: 28.3228 + (Math.random() * 0.05),
      img: 'https://images.unsplash.com/photo-152327533bc62-171b502214a1?w=150'
    };
    setOrders([newOrder, ...orders]);
    setIsNewOrderModalOpen(false);
  };

  const handleDelete = (id, e) => {
    e.stopPropagation();
    setOrders(orders.filter(o => o.id !== id));
    if (selectedOrder?.id === id) setSelectedOrder(null);
  };

  const updateStatus = (id, status) => {
    setOrders(orders.map(o => o.id === id ? { ...o, status } : o));
    if (selectedOrder?.id === id) setSelectedOrder({ ...selectedOrder, status });
  };

  const filteredOrders = orders.filter(o => 
    o.customer.toLowerCase().includes(searchTerm.toLowerCase()) || 
    o.id.includes(searchTerm)
  );

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      {/* SIDEBAR */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col p-6 shrink-0">
        <div className="flex items-center gap-3 mb-10 px-2 font-bold text-indigo-600 text-xl tracking-tight">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Navigation size={18} fill="currentColor" />
          </div>
          <span className="text-slate-900">TrackFlow</span>
        </div>
        <nav className="space-y-1 flex-1">
          <SideItem icon={<LayoutDashboard size={18}/>} label="Overview" />
          <SideItem icon={<Package size={18}/>} label="Shipments" active />
          <SideItem icon={<Users size={18}/>} label="Fleet Managers" />
          <div className="pt-4 mt-4 border-t border-slate-100">
            <SideItem icon={<Settings size={18}/>} label="Settings" />
          </div>
        </nav>
      </aside>

      {/* MAIN VIEW */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0">
          <div className="relative w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              className="w-full pl-10 pr-4 py-2.5 bg-slate-100 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              placeholder="Search by Order ID or Client..."
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"><Bell size={20}/></button>
            <button 
                onClick={() => setIsNewOrderModalOpen(true)}
                className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100 flex items-center gap-2 transition-transform active:scale-95"
            >
                <Plus size={18}/> New Order
            </button>
          </div>
        </header>

        <main className="flex-1 p-8 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50/50 text-slate-500 font-bold uppercase text-[10px] tracking-widest border-b border-slate-100">
                <tr>
                  <th className="px-6 py-5">Item Details</th>
                  <th className="px-6 py-5">Recipient</th>
                  <th className="px-6 py-5">Current Status</th>
                  <th className="px-6 py-5 text-right">Value</th>
                  <th className="px-6 py-5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOrders.map(order => (
                  <tr 
                    key={order.id} 
                    onClick={() => setSelectedOrder(order)}
                    className="group hover:bg-indigo-50/30 transition-all cursor-pointer"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <img src={order.img} className="w-12 h-12 rounded-xl object-cover ring-2 ring-slate-100" alt=""/>
                        <div>
                          <p className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{order.name}</p>
                          <p className="text-[10px] font-mono text-slate-400 tracking-tighter">{order.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-semibold text-slate-600">{order.customer}</td>
                    <td className="px-6 py-4"><StatusBadge status={order.status} /></td>
                    <td className="px-6 py-4 text-right font-black text-slate-900">{currency} {order.total.toLocaleString()}</td>
                    <td className="px-6 py-4 text-right">
                      <button onClick={(e) => handleDelete(order.id, e)} className="p-2 text-slate-300 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100">
                        <Trash2 size={18}/>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setSelectedOrder(null)} />
          <div className={`relative bg-white h-full shadow-2xl flex flex-col transition-all duration-500 ease-in-out ${isMapMaximized ? 'w-full' : 'w-[550px]'}`}>
            
            <div className="p-6 border-b flex justify-between items-center bg-white z-10">
              <div className="flex items-center gap-4">
                <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><X size={20}/></button>
                <div>
                  <h3 className="font-bold text-slate-900 leading-none mb-1">{selectedOrder.name}</h3>
                  <p className="text-[11px] font-bold text-indigo-500 uppercase tracking-widest">{selectedOrder.id}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                 <button 
                  onClick={() => setIsMapMaximized(!isMapMaximized)}
                  className="p-2.5 bg-slate-100 text-slate-600 hover:bg-indigo-600 hover:text-white rounded-xl transition-all"
                  title="Toggle Map Size"
                >
                  {isMapMaximized ? <Minimize2 size={18}/> : <Maximize2 size={18}/>}
                </button>
              </div>
            </div>

            <div className={`relative transition-all duration-500 ${isMapMaximized ? 'flex-1' : 'h-[350px]'} bg-slate-900 overflow-hidden`}>
               <MapContainer center={[selectedOrder.lat, selectedOrder.lng]} zoom={7} zoomControl={false} style={{ height: '100%', width: '100%' }}>
                  {/* <TileLayer url="https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png" /> */}
                  <TileLayer url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" />
                  <Marker position={[selectedOrder.lat, selectedOrder.lng]} icon={createCustomIcon(selectedOrder.img, selectedOrder.status)}>
                    <Popup className="custom-popup">
                      <div className="p-1 text-center">
                        <img src={selectedOrder.img} className="w-44 h-auto rounded-lg object-cover mb-2 border-2 border-indigo-500" alt=""/>
                        <p className="font-bold text-slate-900 m-0">{selectedOrder.name}</p>
                        <p className="text-[10px] text-slate-500 m-0">{selectedOrder.customer}</p>
                        <p className="text-[10px] text-slate-500 m-0">{selectedOrder.date}</p>
                        <p className="text-[10px] text-slate-500 m-0">{selectedOrder.total}</p>
                        <p className="text-[10px] text-slate-500 m-0">{selectedOrder.status}</p>
                      </div>
                    </Popup>
                  </Marker>
                  <RecenterMap lat={selectedOrder.lat} lng={selectedOrder.lng} />
               </MapContainer>
               
               {!isMapMaximized && (
                  <div className="absolute bottom-4 left-4 z-[400] bg-white/90 backdrop-blur p-3 rounded-2xl shadow-xl border border-white/20">
                    <div className="flex items-center gap-3">
                        <div className="bg-indigo-600 p-2 rounded-lg text-white"><MapPin size={16}/></div>
                        <div className="text-[10px] font-mono font-bold text-slate-700">
                            {selectedOrder.lat.toFixed(5)}, {selectedOrder.lng.toFixed(5)}
                        </div>
                    </div>
                  </div>
               )}
            </div>

            {!isMapMaximized && (
                <div className="p-8 flex-1 overflow-y-auto space-y-8 bg-white animate-in slide-in-from-bottom-5">
                    <div className="grid grid-cols-2 gap-6">
                        <DetailBox label="Recipient" value={selectedOrder.customer} />
                        <DetailBox label="Date Shipped" value={selectedOrder.date} />
                        <DetailBox label="Order Total" value={`${currency} ${selectedOrder.total.toLocaleString()}`} />
                        <DetailBox label="Reference" value="#LUS-TRACK-2026" />
                    </div>

                    <div className="space-y-4 pt-4 border-t border-slate-100">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Update Logistics Status</p>
                        <div className="grid grid-cols-3 gap-3">
                        {['Pending', 'Completed', 'Canceled'].map(s => (
                            <button 
                            key={s}
                            onClick={() => updateStatus(selectedOrder.id, s)}
                            className={`py-3 rounded-2xl text-[10px] font-bold border transition-all active:scale-95 ${selectedOrder.status === s ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-slate-50 border-slate-100 text-slate-500 hover:bg-white hover:border-indigo-300'}`}
                            >
                            {s}
                            </button>
                        ))}
                        </div>
                    </div>
                </div>
            )}
          </div>
        </div>
      )}

      {isNewOrderModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setIsNewOrderModalOpen(false)} />
          <form onSubmit={handleAddOrder} className="relative bg-white w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl animate-in zoom-in-95">
            <h3 className="text-2xl font-black text-slate-900 mb-2">New Shipment</h3>
            <p className="text-slate-400 text-sm mb-8">Register a new item into the tracking system.</p>
            <div className="space-y-4">
              <FormInput name="product" placeholder="Product Name (e.g. Solar Inverter)" label="Product" />
              <FormInput name="customer" placeholder="Recipient Name" label="Recipient" />
              <FormInput name="amount" type="number" placeholder="Value in ZMW" label="Value" />
              <button className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition-all mt-4 active:scale-95">
                Register & Track
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};


const FormInput = ({ label, ...props }) => (
    <div className="space-y-1.5">
        <label className="text-[10px] font-bold text-slate-500 uppercase ml-1 tracking-widest">{label}</label>
        <input className="w-full px-4 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500 transition-all text-sm" required {...props} />
    </div>
)

const DetailBox = ({ label, value }) => (
    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">{label}</p>
        <p className="text-sm font-bold text-slate-800">{value}</p>
    </div>
)

const RecenterMap = ({ lat, lng }) => {
  const map = useMap();
  useEffect(() => { 
      map.setView([lat, lng], 13);
      setTimeout(() => map.invalidateSize(), 500);
  }, [lat, lng, map]);
  return null;
};

const StatusBadge = ({ status }) => {
  const styles = {
    Completed: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    Pending: 'bg-amber-50 text-amber-600 border-amber-100',
    Canceled: 'bg-rose-50 text-rose-600 border-rose-100',
  };
  return <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border ${styles[status]}`}>{status}</span>;
};

const SideItem = ({ icon, label, active = false }) => (
  <div className={`flex items-center gap-3 px-4 py-3.5 rounded-2xl cursor-pointer transition-all duration-300 ${active ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100 font-bold translate-x-1' : 'text-slate-400 hover:bg-slate-50 hover:text-slate-900'}`}>
    {icon} <span className="text-sm">{label}</span>
  </div>
);

export default OrderTrackingAdmin;